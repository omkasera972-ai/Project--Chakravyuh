# FastAPI Python Server for Smart Detection App (Bharat 2.0 Tech Stack)
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from backend.routers import auth, ai_engine, modules

app = FastAPI(
    title="Project Chakravyuh - Bharat 2.0 AI Backend",
    description="High-performance FastAPI layer powered by OpenCV, YOLO, EasyOCR, MongoDB & Face Recognition",
    version="2.0.0"
)

# Enable CORS for React Frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include Routers
app.include_router(auth.router)
app.include_router(ai_engine.router)
app.include_router(modules.router)

@app.get("/")
async def root():
    return {
        "status": "online",
        "app": "Project Chakravyuh - Multi-Module AI Gateway",
        "tech_stack": [
            "Python 3.10+",
            "FastAPI Layer",
            "OpenCV & YOLO AI Inference Engine",
            "Face Recognition / Dlib",
            "EasyOCR ANPR Scanner",
            "MongoDB & Event Storage"
        ],
        "version": "2.0.0"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("backend.main:app", host="0.0.0.0", port=8000, reload=True)
