# FastAPI Auth Router for 5 Security Modules
from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from typing import Optional, Dict

router = APIRouter(prefix="/api/auth", tags=["Authentication"])

MODULE_DETAILS = {
    "attendance": {
        "title": "Smart Attendance System",
        "role": "Attendance Manager / HR Administrator",
        "clearance": "Level 1 - HR & Staff Access"
    },
    "criminal-tracking": {
        "title": "Criminal Identification & Tracking System",
        "role": "Law Enforcement Detective / Officer",
        "clearance": "Level 4 - High Security Law Enforcement"
    },
    "anpr": {
        "title": "Automatic Number Plate Recognition (ANPR)",
        "role": "Traffic Control / RTO Command Officer",
        "clearance": "Level 2 - Traffic Monitoring"
    },
    "missing-child": {
        "title": "Missing Children Rescue Network",
        "role": "Child Welfare & Rescue Task Force Coordinator",
        "clearance": "Level 3 - Special Task Force"
    },
    "defence": {
        "title": "Defence Asset & Personnel Tracking System",
        "role": "Garrison Commander / Defence Administrator",
        "clearance": "Level 5 - Top Secret Military Clearance"
    }
}

class LoginRequest(BaseModel):
    moduleId: str
    username: str
    password: str
    role: Optional[str] = None

class RegisterRequest(BaseModel):
    moduleId: str
    fullName: str
    badgeId: str
    email: str
    password: str
    role: Optional[str] = None

@router.get("/module/{module_id}")
async def get_module_auth_info(module_id: str):
    if module_id not in MODULE_DETAILS:
        raise HTTPException(status_code=404, detail="Module not recognized")
    return {
        "status": "success",
        "moduleId": module_id,
        "details": MODULE_DETAILS[module_id]
    }

@router.post("/login")
async def login_to_module(req: LoginRequest):
    if req.moduleId not in MODULE_DETAILS:
        raise HTTPException(status_code=400, detail="Invalid Module specified")
    
    module_info = MODULE_DETAILS[req.moduleId]
    user_data = {
        "username": req.username or "Officer Admin",
        "name": req.username.capitalize() if req.username else "Command Admin",
        "role": req.role or module_info["role"],
        "badge": f"BADGE-{req.moduleId.upper()[:4]}-2026",
        "clearance": module_info["clearance"],
        "activeModule": req.moduleId,
        "isAuthenticated": True,
        "token": f"token-{req.moduleId}-{req.username}-sec2026"
    }
    return {"status": "success", "message": f"Authenticated for {module_info['title']}", "user": user_data}

@router.post("/register")
async def register_user(req: RegisterRequest):
    if req.moduleId not in MODULE_DETAILS:
        raise HTTPException(status_code=400, detail="Invalid Module specified")
        
    return {
        "status": "success",
        "message": f"Account registered successfully for {req.fullName} in {MODULE_DETAILS[req.moduleId]['title']}",
        "badgeId": req.badgeId
    }
