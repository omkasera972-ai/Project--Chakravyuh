import React from 'react';
import {
  CameraBgSvg,
  AlertBgSvg,
  AttendanceBgSvg,
  VehicleBgSvg,
  ChildSearchBgSvg,
  ShieldBgSvg,
  MapBgSvg,
  CpuBgSvg,
  WatchlistBgSvg,
  ReportBgSvg
} from './common/CardBackgroundIcons';

export const StatCard = ({ title, value, subtext, icon: Icon, onClick, indicatorDot = null }) => {
  const isHighPriority = subtext === 'High Priority';

  // Helper to pick matching SVG illustration
  const renderBgIllustration = () => {
    const t = (title || '').toLowerCase();
    if (t.includes('camera') || t.includes('node') || t.includes('cctv')) return <CameraBgSvg className="w-12 h-12 text-blue-500" />;
    if (t.includes('alert') || t.includes('threat') || strokeRed(t)) return <AlertBgSvg className="w-12 h-12 text-red-500" />;
    if (t.includes('attend') || t.includes('present') || t.includes('employee')) return <AttendanceBgSvg className="w-12 h-12 text-emerald-500" />;
    if (t.includes('vehicle') || t.includes('anpr') || t.includes('speed') || t.includes('toll')) return <VehicleBgSvg className="w-12 h-12 text-amber-500" />;
    if (t.includes('child') || t.includes('missing') || t.includes('rescue')) return <ChildSearchBgSvg className="w-12 h-12 text-purple-500" />;
    if (t.includes('defence') || t.includes('radar') || t.includes('shield') || t.includes('target')) return <ShieldBgSvg className="w-12 h-12 text-blue-600" />;
    if (t.includes('map') || t.includes('location') || t.includes('zone')) return <MapBgSvg className="w-12 h-12 text-emerald-600" />;
    if (t.includes('latency') || t.includes('engine') || t.includes('ai') || t.includes('cpu')) return <CpuBgSvg className="w-12 h-12 text-indigo-500" />;
    if (t.includes('watchlist') || t.includes('suspect') || t.includes('fir')) return <WatchlistBgSvg className="w-12 h-12 text-amber-600" />;
    return <ReportBgSvg className="w-12 h-12 text-slate-500" />;
  };

  const strokeRed = (txt) => txt.includes('warning') || txt.includes('critical');

  return (
    <div
      onClick={onClick}
      className={`relative overflow-hidden bg-white border border-gray-200/90 rounded-2xl p-4 flex items-center justify-between transition-all shadow-xs group ${
        onClick ? 'cursor-pointer hover:border-gray-400 hover:shadow-sm' : ''
      }`}
    >
      <div className="flex flex-col justify-between relative z-10">
        <span className="text-[12px] font-semibold text-gray-700 dark:text-gray-300 tracking-tight flex items-center mb-1.5">
          {title}
          {indicatorDot === 'green' && (
            <span className="w-2 h-2 rounded-full bg-emerald-500 ml-1.5 inline-block" />
          )}
          {indicatorDot === 'red' && (
            <span className="w-2 h-2 rounded-full bg-red-500 ml-1.5 inline-block" />
          )}
        </span>
        <div className="flex flex-col">
          <span className="text-2xl font-bold text-gray-950 dark:text-white tracking-tight leading-none mb-1">
            {value}
          </span>
          <span className={`text-[11px] font-medium leading-none ${
            isHighPriority ? 'text-red-500 font-semibold' : 'text-gray-500 dark:text-gray-400'
          }`}>
            {subtext}
          </span>
        </div>
      </div>
      <div className="w-11 h-11 rounded-xl bg-[#f8f9fa] border border-gray-100 flex items-center justify-center text-gray-700 flex-shrink-0 relative z-10">
        {Icon && <Icon className="w-5 h-5 stroke-[1.75]" />}
      </div>
      {renderBgIllustration()}
    </div>
  );
};
