import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import {
  Home,
  UserCheck,
  ScanFace,
  Car,
  User,
  ShieldCheck,
  Video,
  Bell,
  Map,
  FileText,
  Settings,
  LogOut,
  LayoutGrid
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const Sidebar = () => {
  const { logout, alerts, isSidebarCollapsed, activeModule } = useApp();
  const navigate = useNavigate();

  const currentModuleKey = activeModule || 'attendance';
  const activeAlertsCount = alerts.filter(a => a.status === 'Active' && (a.module ? a.module === currentModuleKey : true)).length;
  const basePath = `/portal/${currentModuleKey}`;

  // Module-Specific primary navigation item
  const getModuleSpecificNavItem = (modKey) => {
    switch (modKey) {
      case 'attendance':
        return { name: 'Attendance System', path: `${basePath}/attendance`, icon: UserCheck };
      case 'criminal-tracking':
        return { name: 'Criminal Tracking', path: `${basePath}/criminal-tracking`, icon: ScanFace };
      case 'anpr':
        return { name: 'ANPR System', path: `${basePath}/anpr`, icon: Car };
      case 'missing-child':
        return { name: 'Missing Children', path: `${basePath}/missing-child`, icon: User };
      case 'defence':
        return { name: 'Defence Tracker', path: `${basePath}/defence`, icon: ShieldCheck };
      default:
        return { name: 'Attendance System', path: `${basePath}/attendance`, icon: UserCheck };
    }
  };

  // Dedicated Nav Items: NO OTHER 4 MODULES SHOWN!
  const navItems = [
    { name: 'Dashboard', path: `${basePath}/dashboard`, icon: Home },
    getModuleSpecificNavItem(currentModuleKey),
    { name: 'Camera Network', path: `${basePath}/cameras`, icon: Video },
    { name: 'Alerts & Triage', path: `${basePath}/alerts`, icon: Bell, badge: activeAlertsCount > 0 ? activeAlertsCount : null },
    { name: 'Live Maps', path: `${basePath}/maps`, icon: Map },
    { name: 'Reports & Logs', path: `${basePath}/reports`, icon: FileText },
    { name: 'Settings', path: `${basePath}/settings`, icon: Settings },
  ];

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <aside
      className={`bg-white dark:bg-[#111318] border-r border-gray-200 dark:border-gray-800 flex flex-col justify-between h-full select-none p-3 flex-shrink-0 transition-all duration-300 overflow-hidden ${
        isSidebarCollapsed ? 'w-20 items-center px-2' : 'w-72'
      }`}
    >
      {/* Navigation Menu */}
      <nav className="space-y-1.5 w-full overflow-hidden">
        {navItems.map((item) => {
          const Icon = item.icon;
          return (
            <NavLink
              key={item.path}
              to={item.path}
              title={isSidebarCollapsed ? item.name : undefined}
              className={({ isActive }) =>
                `flex items-center ${isSidebarCollapsed ? 'justify-center px-2 py-3' : 'justify-between px-4 py-3'} rounded-xl text-base transition-all ${
                  isActive
                    ? 'bg-indigo-50 dark:bg-indigo-950/50 text-indigo-700 dark:text-indigo-300 font-bold shadow-xs border border-indigo-200 dark:border-indigo-800/60'
                    : 'text-gray-700 dark:text-gray-300 font-medium hover:text-gray-950 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-800/70'
                }`
              }
            >
              <div className="flex items-center space-x-3.5">
                <Icon className="w-5 h-5 flex-shrink-0 stroke-[2]" />
                {!isSidebarCollapsed && <span className="tracking-tight">{item.name}</span>}
              </div>
              {!isSidebarCollapsed && item.badge && (
                <span className="px-2.5 py-0.5 text-xs font-bold rounded-full bg-red-100 dark:bg-red-950/80 text-red-600 dark:text-red-400 border border-red-200 dark:border-red-800">
                  {item.badge}
                </span>
              )}
            </NavLink>
          );
        })}
      </nav>

      {/* Logout Action pinned at bottom */}
      <div className="pt-3 w-full border-t border-gray-200 dark:border-gray-800 mt-2">
        <button
          onClick={handleLogout}
          title={isSidebarCollapsed ? "Exit Portal" : undefined}
          className={`w-full flex items-center ${isSidebarCollapsed ? 'justify-center px-2 py-3' : 'space-x-3.5 px-4 py-3'} rounded-xl text-base font-semibold text-gray-700 dark:text-gray-300 hover:text-red-600 dark:hover:text-red-400 bg-gray-50 dark:bg-[#171a22] border border-gray-200 dark:border-gray-800 hover:bg-red-50 dark:hover:bg-red-950/30 transition-all shadow-xs`}
        >
          <LogOut className="w-5 h-5 flex-shrink-0 stroke-[2]" />
          {!isSidebarCollapsed && <span>Exit Portal</span>}
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;
