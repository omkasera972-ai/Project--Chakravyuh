export const initialKPIs = {
  totalPersonnel: { value: '1,248', label: 'Total Person', subtext: 'Active Officers' },
  activeCameras: { value: '523', label: 'Active Cameras', subtext: 'Online' },
  activeAlerts: { value: '12', label: 'Active Alerts', subtext: 'High Priority' },
  criminalsTracked: { value: '215', label: 'Criminals Tracked', subtext: 'In Watchlist' },
  missingChildren: { value: '28', label: 'Missing Children', subtext: 'Active Cases' },
};

export const initialCameras = [
  {
    id: 'CAM-DESKTOP',
    code: 'Cam 01 - Live Desktop Webcam',
    name: 'Primary Desktop Biometric Terminal',
    status: 'Online',
    type: 'HD Biometric Webcam',
    resolution: '1280x720 @ 60fps',
    zone: 'Admin Entrance - Biometric Check-in',
    lat: 22.7196,
    lng: 75.8577,
    lastActivity: 'Live Webcam Active',
    aiDetections: 1,
    alertsCount: 0,
    feedUrl: 'webcam'
  },
  {
    id: 'CAM-02',
    code: 'Cam 02 - Campus Main Gate',
    name: 'School & College Main Entrance Arch',
    status: 'Online',
    type: '4K Campus Security CCTV',
    resolution: '3840x2160 @ 60fps',
    zone: 'Zone 1 - Main Gate Entrance',
    lat: 22.7240,
    lng: 75.8650,
    lastActivity: 'Campus Gate Surveillance Active',
    aiDetections: 342,
    alertsCount: 1,
    imageSrc: 'https://images.unsplash.com/photo-1541829070764-84a7d30dd3f3?w=1000&auto=format&fit=crop&q=80'
  },
  {
    id: 'CAM-03',
    code: 'Cam 03 - Academic & Science Wing',
    name: 'Science Building Corridor Camera',
    status: 'Online',
    type: '4K AI Bullet Camera',
    resolution: '3840x2160 @ 60fps',
    zone: 'Zone 3 - Academic Wing',
    lat: 22.7500,
    lng: 75.8900,
    lastActivity: 'Hallway AI Detection Active',
    aiDetections: 914,
    alertsCount: 2,
    imageSrc: 'https://images.unsplash.com/photo-1562774053-701939374585?w=1000&auto=format&fit=crop&q=80'
  },
  {
    id: 'CAM-04',
    code: 'Cam 04 - Central Library Quad',
    name: 'Campus Library & Study Quad',
    status: 'Online',
    type: '1080p Panoramic 360',
    resolution: '1920x1080 @ 30fps',
    zone: 'Zone 2 - Library Quadrangle',
    lat: 22.7150,
    lng: 75.8450,
    lastActivity: 'Quadrangle Dome Camera Active',
    aiDetections: 512,
    alertsCount: 0,
    imageSrc: 'https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=1000&auto=format&fit=crop&q=80'
  },
  {
    id: 'CAM-05',
    code: 'Cam 05 - Student Cafeteria Hub',
    name: 'Student Cafeteria Courtyard Camera',
    status: 'Online',
    type: '1080p Dome CCTV',
    resolution: '1920x1080 @ 30fps',
    zone: 'Zone 4 - Student Activity Hub',
    lat: 22.7200,
    lng: 75.8500,
    lastActivity: 'Cafeteria Stream Active',
    aiDetections: 284,
    alertsCount: 0,
    imageSrc: 'https://images.unsplash.com/photo-1498243691581-b145c3f54a5a?w=1000&auto=format&fit=crop&q=80'
  },
  {
    id: 'CAM-06',
    code: 'Cam 06 - Sports Complex Ground',
    name: 'Athletic Field & Gymnasium Gate',
    status: 'Online',
    type: '4K LPR Bullet Camera',
    resolution: '3840x2160 @ 60fps',
    zone: 'Zone 5 - Sports Facility',
    lat: 22.7300,
    lng: 75.8600,
    lastActivity: 'Perimeter Ground Camera Active',
    aiDetections: 198,
    alertsCount: 1,
    imageSrc: 'https://images.unsplash.com/photo-1577495508048-b635879837f1?w=1000&auto=format&fit=crop&q=80'
  }
];

export const initialAlerts = [
  // --- CRIMINAL TRACKING ALERTS ---
  {
    id: 'ALT-101',
    module: 'criminal-tracking',
    type: 'Watchlist Intercept',
    title: 'WATCHLIST INTERCEPT: Rohan "Shadow" Roy',
    location: 'Highway - North Toll Corridor',
    camera: 'CAM-03',
    priority: 'Critical',
    timeAgo: 'Just now',
    description: 'AI Facial Recognition matched suspect Rohan "Shadow" Roy (W-9021) with 94% confidence.',
    status: 'Active',
    colorTheme: 'red',
    icon: 'ScanFace'
  },
  {
    id: 'ALT-102',
    module: 'criminal-tracking',
    type: 'Possible Match',
    title: 'POSSIBLE MATCH: Yuvraj Patidar',
    location: 'City Center Plaza Exit 4',
    camera: 'CAM-02',
    priority: 'High',
    timeAgo: '2 min ago',
    description: 'AI Camera Sweep identified probable match (92.4% confidence) for Wanted Suspect at CAM-02.',
    status: 'Active',
    colorTheme: 'yellow',
    icon: 'Bell'
  },
  {
    id: 'ALT-108',
    module: 'criminal-tracking',
    type: 'Suspect Intercept',
    title: 'CRIMINAL INTERCEPT: Suspect Identified',
    location: 'Central Railway Station',
    camera: 'CAM-04',
    priority: 'Critical',
    timeAgo: '15 min ago',
    description: 'Facial recognition confidence verified by command control room duty officer.',
    status: 'Active',
    colorTheme: 'red',
    icon: 'ScanFace'
  },
  {
    id: 'ALT-112',
    module: 'criminal-tracking',
    type: 'Biometric Sweep',
    title: 'BIOMETRIC SWEEP: Vikram "Snake" Thakur',
    location: 'Interstate Bus Terminal Gate 3',
    camera: 'CAM-07',
    priority: 'High',
    timeAgo: '28 min ago',
    description: 'Optical AI node flagged wanted fugitive matching Interpol Red Corner Notice criteria.',
    status: 'Active',
    colorTheme: 'yellow',
    icon: 'ScanFace'
  },
  {
    id: 'ALT-113',
    module: 'criminal-tracking',
    type: 'Watchlist Match',
    title: 'WATCHLIST MATCH: Sameer "Zero" Khan',
    location: 'Airport Passenger Drop Zone',
    camera: 'CAM-11',
    priority: 'Critical',
    timeAgo: '42 min ago',
    description: 'High priority watchlist target detected at main terminal entrance by AI CCTV array.',
    status: 'Active',
    colorTheme: 'red',
    icon: 'ScanFace'
  },

  // --- ANPR ALERTS ---
  {
    id: 'ALT-104',
    module: 'anpr',
    type: 'ANPR Hit',
    title: 'ANPR HIT: Blacklisted Vehicle MP09-AB-1234',
    location: 'Highway Toll Station Corridor',
    camera: 'CAM-ANPR-01',
    priority: 'Critical',
    timeAgo: 'Just now',
    description: 'Blacklisted vehicle (Stolen SUV - Black Scorpio) intercepted at Highway Northbound check lane.',
    status: 'Active',
    colorTheme: 'red',
    icon: 'Car'
  },
  {
    id: 'ALT-107',
    module: 'anpr',
    type: 'Speed Violation',
    title: 'SPEED INTERCEPT: Expressway Corridor (142 km/h)',
    location: 'Bypass Expressway Km 14',
    camera: 'CAM-ANPR-03',
    priority: 'High',
    timeAgo: '5 min ago',
    description: 'Speed intercept ticket generated (142 km/h in 80 zone) and auto-dispatched to PCR mobile.',
    status: 'Active',
    colorTheme: 'yellow',
    icon: 'Car'
  },
  {
    id: 'ALT-110',
    module: 'anpr',
    type: 'ANPR Scan',
    title: 'EXPIRED REGISTRATION: Vehicle KA-05-MN-9921',
    location: 'Ring Road Toll Plaza Lane 2',
    camera: 'CAM-ANPR-08',
    priority: 'Medium',
    timeAgo: '18 min ago',
    description: 'Commercial vehicle with expired permit and pending e-challan dues detected.',
    status: 'Active',
    colorTheme: 'yellow',
    icon: 'Car'
  },
  {
    id: 'ALT-114',
    module: 'anpr',
    type: 'Stolen Vehicle',
    title: 'STOLEN VEHICLE ALERT: White Swift (MH-12-PQ-4028)',
    location: 'Metro Station Underpass',
    camera: 'CAM-ANPR-05',
    priority: 'Critical',
    timeAgo: '30 min ago',
    description: 'Automatic OCR plate scanner matched active FIR theft log. PCR Intercept unit dispatched.',
    status: 'Active',
    colorTheme: 'red',
    icon: 'Car'
  },
  {
    id: 'ALT-115',
    module: 'anpr',
    type: 'Fake Plate Hit',
    title: 'FAKE PLATE ANOMALY: Mismatched Chassis Plate',
    location: 'City Boundary Checkpost',
    camera: 'CAM-ANPR-12',
    priority: 'High',
    timeAgo: '45 min ago',
    description: 'Plate optical scanner detected fake registration number on luxury sedan.',
    status: 'Active',
    colorTheme: 'yellow',
    icon: 'Car'
  },

  // --- MISSING CHILD ALERTS ---
  {
    id: 'ALT-105',
    module: 'missing-child',
    type: 'Missing Child Spotlight',
    title: 'CHILD LOCATED: Aarav Sharma (MC-2026-081)',
    location: 'Vijay Nagar Central Park Gate 2',
    camera: 'CAM-MC-02',
    priority: 'High',
    timeAgo: 'Just now',
    description: 'Case MC-2026-081: 7-year old child positive AI facial match verified by transit patrol team.',
    status: 'Active',
    colorTheme: 'purple',
    icon: 'User'
  },
  {
    id: 'ALT-116',
    module: 'missing-child',
    type: 'Missing Child Active',
    title: 'MISSING CHILD ALERT: Priya Patel (MC-2026-094)',
    location: 'Railway Station Platform 4',
    camera: 'CAM-MC-09',
    priority: 'Critical',
    timeAgo: '6 min ago',
    description: 'Case MC-2026-094: 5-year old child reported missing from waiting hall. CCTV mesh active.',
    status: 'Active',
    colorTheme: 'purple',
    icon: 'User'
  },
  {
    id: 'ALT-117',
    module: 'missing-child',
    type: 'Child Recovery',
    title: 'CHILD MATCH DETECTED: Kabir Verma (MC-2026-102)',
    location: 'Interstate Bus Terminal Stand 5',
    camera: 'CAM-MC-04',
    priority: 'High',
    timeAgo: '20 min ago',
    description: 'Child protection unit escorting child back to local police desk for parent handover.',
    status: 'Active',
    colorTheme: 'purple',
    icon: 'User'
  },
  {
    id: 'ALT-118',
    module: 'missing-child',
    type: 'Missing Child Active',
    title: 'MISSING CHILD ALERT: Ananya Singh (MC-2026-118)',
    location: 'City Shopping Mall Food Court',
    camera: 'CAM-MC-14',
    priority: 'Critical',
    timeAgo: '35 min ago',
    description: '8-year old girl missing from department store. Mall security nodes scanning exits.',
    status: 'Active',
    colorTheme: 'purple',
    icon: 'User'
  },
  {
    id: 'ALT-119',
    module: 'missing-child',
    type: 'Child Recovery',
    title: 'CHILD VERIFIED SAFE: Rohan Das (MC-2026-077)',
    location: 'Government Hospital General Ward',
    camera: 'CAM-MC-01',
    priority: 'High',
    timeAgo: '50 min ago',
    description: 'Child identified by hospital recovery desk personnel. Family notified.',
    status: 'Active',
    colorTheme: 'purple',
    icon: 'User'
  },

  // --- DEFENCE TACTICAL ALERTS ---
  {
    id: 'ALT-106',
    module: 'defence',
    type: 'Perimeter Breach',
    title: 'UNAUTHORIZED MOVEMENT DETECTED: Defense Zone 3',
    location: 'Armory Vault Gate 2 • CAM-06',
    camera: 'CAM-06',
    priority: 'Critical',
    timeAgo: 'Just now',
    description: 'Thermal perimeter RADAR detected unauthorized movement near ammunition depot outer fence.',
    status: 'Active',
    colorTheme: 'red',
    icon: 'Shield'
  },
  {
    id: 'ALT-120',
    module: 'defence',
    type: 'Drone Incursion',
    title: 'DRONE RADAR INCURSION: Airbase Perimeter Sector B',
    location: 'Northern Flight Line Corridor',
    camera: 'CAM-DEF-02',
    priority: 'Critical',
    timeAgo: '4 min ago',
    description: 'Unidentified micro-UAV thermal signature detected at 150m altitude. Countermeasure active.',
    status: 'Active',
    colorTheme: 'red',
    icon: 'Shield'
  },
  {
    id: 'ALT-121',
    module: 'defence',
    type: 'Vault Access',
    title: 'ARMORY ACCESS CLEARANCE: Garrison Vault Gate 1',
    location: 'Underground Munitions Vault',
    camera: 'CAM-DEF-08',
    priority: 'High',
    timeAgo: '16 min ago',
    description: 'Biometric fingerprint & iris clearance log verified for Duty Commander Officer.',
    status: 'Active',
    colorTheme: 'yellow',
    icon: 'Shield'
  },
  {
    id: 'ALT-122',
    module: 'defence',
    type: 'Thermal Perimeter',
    title: 'THERMAL MESH WARN: Border Fence Sensor 4B',
    location: 'Forward Operating Post Alpha',
    camera: 'CAM-DEF-11',
    priority: 'High',
    timeAgo: '32 min ago',
    description: 'Heat signature sweep flagged wildlife motion near tactical fence line. QRT monitoring.',
    status: 'Active',
    colorTheme: 'yellow',
    icon: 'Shield'
  },
  {
    id: 'ALT-123',
    module: 'defence',
    type: 'Tactical Alarm',
    title: 'TACTICAL ALERT: Command Bunker Network Online',
    location: 'Central Tactical Command Vault',
    camera: 'CAM-DEF-01',
    priority: 'Critical',
    timeAgo: '48 min ago',
    description: 'Satellite uplink telemetry and electronic warfare encryption check verified 100% operational.',
    status: 'Active',
    colorTheme: 'red',
    icon: 'Shield'
  },

  // --- ATTENDANCE BIOMETRIC ALERTS ---
  {
    id: 'ALT-103',
    module: 'attendance',
    type: 'Access Control Anomaly',
    title: 'ATTENDANCE ANOMALY: Unauthorized Shift Entrance',
    location: 'Admin Gate 1, Indore HQ',
    camera: 'CAM-ATT-01',
    priority: 'High',
    timeAgo: 'Just now',
    description: 'Unidentified individual attempted biometric turnstile entry without active shift badge clearance.',
    status: 'Active',
    colorTheme: 'blue',
    icon: 'UserCheck'
  },
  {
    id: 'ALT-109',
    module: 'attendance',
    type: 'Access Control',
    title: 'PROXY ATTENDANCE PREVENTED: Turnstile 3',
    location: 'Academic Block Entrance',
    camera: 'CAM-ATT-03',
    priority: 'High',
    timeAgo: '8 min ago',
    description: 'AI Face Match detected card swipe mismatch (Student ID STU-102 photo mismatch).',
    status: 'Active',
    colorTheme: 'blue',
    icon: 'UserCheck'
  },
  {
    id: 'ALT-124',
    module: 'attendance',
    type: 'Roster Check-in',
    title: 'FACULTY BIOMETRIC CHECK-IN: Dr. Rajesh Sharma',
    location: 'Science Auditorium Terminal',
    camera: 'CAM-ATT-05',
    priority: 'High',
    timeAgo: '19 min ago',
    description: 'Instant contactless facial recognition check-in logged at 09:14 AM.',
    status: 'Active',
    colorTheme: 'blue',
    icon: 'UserCheck'
  },
  {
    id: 'ALT-125',
    module: 'attendance',
    type: 'Late Entry Warn',
    title: 'LATE ARRIVAL LOGGED: Shift B Staff Terminal',
    location: 'Engineering Department Gate',
    camera: 'CAM-ATT-08',
    priority: 'Medium',
    timeAgo: '35 min ago',
    description: 'Biometric time-stamp logged 15 minutes past shift schedule cutoff time.',
    status: 'Active',
    colorTheme: 'yellow',
    icon: 'UserCheck'
  },
  {
    id: 'ALT-126',
    module: 'attendance',
    type: 'Visitor Entry',
    title: 'VISITOR PASS ISSUED: Guest Inspector Clearance',
    location: 'Main Reception Desk',
    camera: 'CAM-ATT-02',
    priority: 'Medium',
    timeAgo: '50 min ago',
    description: 'Temporary QR visitor clearance badge activated for Government Inspection team.',
    status: 'Active',
    colorTheme: 'blue',
    icon: 'UserCheck'
  }
];

export const crimeOverviewData = [
  { name: 'Theft', count: 45, percentage: 28.8, color: '#6366f1' },
  { name: 'Assault', count: 30, percentage: 19.2, color: '#f43f5e' },
  { name: 'Fraud', count: 25, percentage: 16.0, color: '#f59e0b' },
  { name: 'Vandalism', count: 20, percentage: 12.8, color: '#10b981' },
  { name: 'Others', count: 36, percentage: 23.2, color: '#8b5cf6' },
];

export const incidentsOverTimeData = [
  { day: 'Mon', incidents: 42 },
  { day: 'Tue', incidents: 65 },
  { day: 'Wed', incidents: 38 },
  { day: 'Thu', incidents: 88 },
  { day: 'Fri', incidents: 72 },
  { day: 'Sat', incidents: 44 },
  { day: 'Sun', incidents: 66 },
];

export const initialPersonnel = [
  {
    id: 'STU-2026-101',
    module: 'attendance',
    name: 'Ananya Sharma',
    department: 'Computer Science',
    role: 'Student',
    entry: '--',
    exit: '--',
    status: 'Absent',
    camera: 'CAM-01',
    avatar: '👩‍🎓',
    photoUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&auto=format&fit=crop&q=80',
    badgeId: 'BADGE-STU-101'
  },
  {
    id: 'TCH-2026-202',
    module: 'attendance',
    name: 'Dr. Vikramaditya Rao',
    department: 'Cyber Security',
    role: 'Teacher',
    entry: '--',
    exit: '--',
    status: 'Absent',
    camera: 'CAM-01',
    avatar: '👨‍🏫',
    photoUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80',
    badgeId: 'BADGE-TCH-202'
  },
  {
    id: 'EMP-2026-303',
    module: 'attendance',
    name: 'Priya Verma',
    department: 'Surveillance Ops',
    role: 'Officer',
    entry: '--',
    exit: '--',
    status: 'Absent',
    camera: 'CAM-01',
    avatar: '👩‍💼',
    photoUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&auto=format&fit=crop&q=80',
    badgeId: 'BADGE-EMP-303'
  },
  {
    id: 'STU-2026-104',
    module: 'attendance',
    name: 'Aarav Gupta',
    department: 'Tactical Command',
    role: 'Student',
    entry: '--',
    exit: '--',
    status: 'Absent',
    camera: 'CAM-01',
    avatar: '👨‍🎓',
    photoUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&auto=format&fit=crop&q=80',
    badgeId: 'BADGE-STU-104'
  }
];

export const initialWatchlist = [
  {
    id: 'W-9021',
    name: 'Rohan "Shadow" Roy',
    riskLevel: 'High Risk',
    crimeType: 'Extortion & Arms Supply',
    lastSeen: 'CAM-03 Highway (North Checkpoint)',
    status: 'Active Alert',
    confidence: '94%',
    photo: '👤',
    photoUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    age: 38,
    aliases: ['Shadow', 'R.R.'],
    recordDate: 'Simulated File #8812',
    details: 'Primary suspect in interstate arms smuggling and extortion syndicate.'
  },
  {
    id: 'W-9022',
    name: 'Deepak Malhotra',
    riskLevel: 'High Risk',
    crimeType: 'Financial Cyber Syndicate',
    lastSeen: 'City Center Mall Zone',
    status: 'Under Watch',
    confidence: '89%',
    photo: '👤',
    photoUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    age: 44,
    aliases: ['Cyber-D', 'DM'],
    recordDate: 'Simulated File #8815',
    details: 'Mastermind behind major banking phishing & ransomware network.'
  },
  {
    id: 'W-9023',
    name: 'Suresh "Blade" Kadam',
    riskLevel: 'Medium Risk',
    crimeType: 'Organized Burglary Ring',
    lastSeen: 'Market Area Bazaar',
    status: 'Under Watch',
    confidence: '82%',
    photo: '👤',
    photoUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80',
    age: 31,
    aliases: ['Blade', 'SK'],
    recordDate: 'Simulated File #8820',
    details: 'Operates commercial store burglary and stolen goods distribution.'
  },
  {
    id: 'W-9024',
    name: 'Tanya Singhania',
    riskLevel: 'High Risk',
    crimeType: 'Counterfeit Currency Network',
    lastSeen: 'MG Road Commercial Lane',
    status: 'Active Alert',
    confidence: '91%',
    photo: '👤',
    photoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    age: 36,
    aliases: ['Queen', 'TS'],
    recordDate: 'Simulated File #8824',
    details: 'Key distributor of high-grade fake currency notes in retail hubs.'
  },
  {
    id: 'W-9025',
    name: 'Manoj Bajpayee (Fictional Target)',
    riskLevel: 'Critical',
    crimeType: 'High-Security Perimeter Breach',
    lastSeen: 'Defense Zone 3 Perimeter',
    status: 'Priority Search',
    confidence: '96%',
    photo: '👤',
    photoUrl: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150&auto=format&fit=crop&q=80',
    age: 49,
    aliases: ['Spectre', 'Target-09'],
    recordDate: 'Simulated File #8830',
    details: 'Involved in restricted military depot intrusion and security bypass.'
  }
];

export const initialVehicles = [
  {
    id: 'VEH-01',
    plate: 'MP09-AB-1234',
    type: 'Black SUV (Scorpio)',
    status: 'Blacklisted',
    reason: 'Stolen / Hit & Run Case #441',
    lastDetected: 'CAM-03 Highway',
    location: 'Northbound Toll Lane 4',
    speed: '88 km/h',
    route: [
      [22.7196, 75.8577],
      [22.7300, 75.8700],
      [22.7400, 75.8850],
      [22.7500, 75.8900]
    ]
  },
  {
    id: 'VEH-02',
    plate: 'MH12-CD-5678',
    type: 'White Sedan (City)',
    status: 'Suspicious',
    reason: 'Altered Registration Hologram',
    lastDetected: 'CAM-01 MG Road',
    location: 'MG Road Intersection',
    speed: '42 km/h',
    route: [
      [22.7100, 75.8500],
      [22.7196, 75.8577]
    ]
  },
  {
    id: 'VEH-03',
    plate: 'DL01-EF-9012',
    type: 'Silver Hatchback (Swift)',
    status: 'Suspicious',
    reason: 'Excess Speed Violation (120 km/h)',
    lastDetected: 'CAM-04 Market Area',
    location: 'Central Ring Junction',
    speed: '76 km/h',
    route: [
      [22.7150, 75.8450],
      [22.7240, 75.8650]
    ]
  },
  {
    id: 'VEH-04',
    plate: 'KA03-GH-3456',
    type: 'Dark Blue Delivery Van',
    status: 'Authorized',
    reason: 'Registered Commercial Delivery',
    lastDetected: 'CAM-02 City Center',
    location: 'Loading Bay 3',
    speed: '25 km/h',
    route: [
      [22.7200, 75.8600],
      [22.7240, 75.8650]
    ]
  }
];

export const initialMissingChildren = [];

export const initialDepotInventory = [
  {
    id: 'DEP-01',
    item: 'INSAS Assault Rifle 5.56mm',
    category: 'Weapon',
    quantity: 42,
    location: 'Depot A - Armory Rack 1',
    status: 'Secure',
    lastChecked: 'Today (Automated Scan)',
    rfidTag: 'RFID-WP-1042'
  },
  {
    id: 'DEP-02',
    item: '5.56x45mm Ammo Box (1000 Rnds)',
    category: 'Ammunition',
    quantity: 18,
    location: 'Depot A - Vault 2',
    status: 'Secure',
    lastChecked: 'Today (Automated Scan)',
    rfidTag: 'RFID-AM-8818'
  },
  {
    id: 'DEP-03',
    item: 'Tactical Level IV Armor Crate',
    category: 'Storage',
    quantity: 7,
    location: 'Depot B - Sector 4',
    status: 'Secure',
    lastChecked: 'Today (Automated Scan)',
    rfidTag: 'RFID-CR-4407'
  },
  {
    id: 'DEP-04',
    item: 'Thermal Night Vision Monocular',
    category: 'Equipment',
    quantity: 15,
    location: 'Depot A - Locker 3',
    status: 'Secure',
    lastChecked: 'Today (Automated Scan)',
    rfidTag: 'RFID-EQ-2015'
  },
  {
    id: 'DEP-05',
    item: 'Encrypted UHF Tactical Radio',
    category: 'Comms',
    quantity: 30,
    location: 'Depot C - Control Room',
    status: 'Secure',
    lastChecked: 'Today (Automated Scan)',
    rfidTag: 'RFID-CM-3330'
  },
  {
    id: 'DEP-06',
    item: 'MP5 Submachine Gun 9mm',
    category: 'Weapon',
    quantity: 24,
    location: 'Depot B - Armory Rack 2',
    status: 'Secure',
    lastChecked: 'Today (Automated Scan)',
    rfidTag: 'RFID-WP-1024'
  }
];

export const initialMovementLogs = [
  {
    id: 'MOV-1001',
    time: '14:20',
    item: '5.56mm Ammo Box (2x)',
    type: 'Authorized Transfer',
    officer: 'Maj. R. K. Singh (BADGE-9945)',
    status: 'Logged & Verified',
    zone: 'Depot A - Vault 2'
  },
  {
    id: 'MOV-1002',
    time: '12:05',
    item: 'INSAS Rifle (4x)',
    type: 'Routine Range Maintenance',
    officer: 'Capt. P. Gupta (BADGE-9948)',
    status: 'Logged & Verified',
    zone: 'Depot A - Armory Rack 1'
  }
];
