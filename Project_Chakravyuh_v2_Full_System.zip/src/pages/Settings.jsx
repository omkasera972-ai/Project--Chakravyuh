import React, { useState } from 'react';
import { User, Shield, Bell, Monitor, Video, Save, CheckCircle2, Lock, Cpu, Globe, Key, Sliders, Smartphone } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { SettingsBgSvg, CpuBgSvg, ShieldBgSvg } from '../components/common/CardBackgroundIcons';

export const Settings = () => {
  const { user, showToast } = useApp();
  const [activeTab, setActiveTab] = useState('profile');

  // Form states
  const [profileForm, setProfileForm] = useState({
    name: user.name || 'Command Officer Ewe',
    role: user.role || 'Law Enforcement Detective / Super Admin',
    badge: 'BADGE-001-ALPHA',
    unit: 'Central Command & Control Room',
    email: 'admin.operations@sda.internal'
  });

  // Toggles & Preferences
  const [preferences, setPreferences] = useState({
    autoAlertSound: true,
    darkHighContrast: true,
    neuralAutoScan: true,
    anprLiveIntercepts: true,
    cctvStreamFps60: true,
    lowBandwidthMode: false,
    retentionDays: 90
  });

  const handleSave = (e) => {
    e.preventDefault();
    showToast('Preferences Saved', 'Command console settings updated successfully.', 'success');
  };

  const tabs = [
    { id: 'profile', label: 'Operator Profile', icon: User, desc: 'Personal details & command credentials' },
    { id: 'security', label: 'Security & Access', icon: Shield, desc: '2FA tokens & session timeouts' },
    { id: 'notifications', label: 'Alert Notifications', icon: Bell, desc: 'Acoustic alarms & real-time dispatch' },
    { id: 'system', label: 'System Preferences', icon: Monitor, desc: 'Console theme & telemetry retention' },
    { id: 'camera', label: 'Camera Stream Settings', icon: Video, desc: '4K AI inferencing & 60 FPS codec' },
  ];

  return (
    <div className="space-y-6 select-none pb-6 min-h-[calc(100vh-8rem)] flex flex-col justify-between">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-[#11141c] border border-gray-200 dark:border-gray-800 p-6 rounded-2xl shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-extrabold text-gray-900 dark:text-white tracking-tight">
              System Settings & Command Configuration
            </h1>
            <span className="px-2.5 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 text-emerald-600 dark:text-emerald-400 text-xs font-bold flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              Engine Online
            </span>
          </div>
          <p className="text-xs sm:text-sm text-gray-500 dark:text-gray-400 mt-1">
            Configure command console parameters, operator access credentials, and neural vision pipeline.
          </p>
        </div>

        <button
          onClick={handleSave}
          className="flex items-center space-x-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white font-bold text-xs shadow-md shadow-indigo-500/20 transition-all cursor-pointer self-start sm:self-auto"
        >
          <Save className="w-4 h-4" />
          <span>Save Console Settings</span>
        </button>
      </div>

      {/* Full Width & Height Cover Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch flex-1">
        {/* Navigation Sidebar with Prominent Large Icons */}
        <div className="lg:col-span-4 bg-white dark:bg-[#11141c] border border-gray-200 dark:border-gray-800 rounded-2xl p-4 space-y-2 shadow-xs h-full">
          <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider block px-3 pb-2 border-b border-gray-100 dark:border-gray-800">
            Control Navigation
          </span>
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isSelected = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`w-full flex items-center space-x-4 p-3.5 rounded-xl text-left transition-all cursor-pointer group ${
                  isSelected
                    ? 'bg-gradient-to-r from-indigo-600 to-blue-600 text-white font-bold shadow-md shadow-indigo-600/20'
                    : 'bg-transparent text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-[#161922] hover:text-gray-900 dark:hover:text-white'
                }`}
              >
                <div className={`p-2.5 rounded-xl flex items-center justify-center transition-colors ${
                  isSelected 
                    ? 'bg-white/20 text-white' 
                    : 'bg-gray-100 dark:bg-[#181b24] text-indigo-600 dark:text-indigo-400 group-hover:bg-indigo-600 group-hover:text-white'
                }`}>
                  <Icon className="w-6 h-6 flex-shrink-0" />
                </div>
                <div>
                  <span className="text-sm font-bold block leading-tight">{tab.label}</span>
                  <span className={`text-[11px] block mt-0.5 ${isSelected ? 'text-indigo-100' : 'text-gray-500 dark:text-gray-400'}`}>
                    {tab.desc}
                  </span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Tab Body Section - Full Cover */}
        <div className="lg:col-span-8 bg-white dark:bg-[#11141c] border border-gray-200 dark:border-gray-800 rounded-2xl p-6 sm:p-8 shadow-xs relative overflow-hidden flex flex-col justify-between h-full">
          <div className="relative z-10 space-y-6">
            {/* Operator Profile Tab */}
            {activeTab === 'profile' && (
              <form onSubmit={handleSave} className="space-y-6">
                <div className="flex items-center space-x-4 pb-6 border-b border-gray-100 dark:border-gray-800">
                  <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-indigo-500 to-blue-600 p-0.5 shadow-md flex-shrink-0">
                    <div className="w-full h-full rounded-[14px] bg-slate-900 flex items-center justify-center text-white text-2xl font-bold">
                      <User className="w-8 h-8 text-indigo-300" />
                    </div>
                  </div>
                  <div>
                    <h3 className="font-extrabold text-gray-900 dark:text-white text-lg">{profileForm.name}</h3>
                    <p className="text-xs text-indigo-600 dark:text-indigo-400 font-bold font-mono mt-0.5">
                      {profileForm.role} • {profileForm.badge}
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-5 text-xs sm:text-sm">
                  <div>
                    <label className="block text-gray-700 dark:text-gray-300 font-bold mb-1.5">Operator Full Name</label>
                    <input
                      type="text"
                      value={profileForm.name}
                      onChange={(e) => setProfileForm({ ...profileForm, name: e.target.value })}
                      className="w-full px-4 py-2.5 bg-gray-50 dark:bg-[#161922] border border-gray-200 dark:border-gray-800 rounded-xl text-gray-900 dark:text-white font-medium focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  <div>
                    <label className="block text-gray-700 dark:text-gray-300 font-bold mb-1.5">Assigned Role</label>
                    <input
                      type="text"
                      disabled
                      value={profileForm.role}
                      className="w-full px-4 py-2.5 bg-gray-100 dark:bg-[#101217] border border-gray-200 dark:border-gray-800 rounded-xl text-gray-400 dark:text-gray-500 font-medium cursor-not-allowed"
                    />
                  </div>

                  <div>
                    <label className="block text-gray-700 dark:text-gray-300 font-bold mb-1.5">Command Unit</label>
                    <input
                      type="text"
                      value={profileForm.unit}
                      onChange={(e) => setProfileForm({ ...profileForm, unit: e.target.value })}
                      className="w-full px-4 py-2.5 bg-gray-50 dark:bg-[#161922] border border-gray-200 dark:border-gray-800 rounded-xl text-gray-900 dark:text-white font-medium focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  <div>
                    <label className="block text-gray-700 dark:text-gray-300 font-bold mb-1.5">Internal Secure Email</label>
                    <input
                      type="email"
                      value={profileForm.email}
                      onChange={(e) => setProfileForm({ ...profileForm, email: e.target.value })}
                      className="w-full px-4 py-2.5 bg-gray-50 dark:bg-[#161922] border border-gray-200 dark:border-gray-800 rounded-xl text-gray-900 dark:text-white font-medium focus:outline-none focus:border-indigo-500"
                    />
                  </div>
                </div>

                <div className="pt-4 border-t border-gray-100 dark:border-gray-800 flex justify-end">
                  <button
                    type="submit"
                    className="flex items-center space-x-2 px-5 py-2.5 bg-gray-900 dark:bg-white text-white dark:text-gray-950 font-bold rounded-xl hover:bg-black dark:hover:bg-gray-100 text-xs transition-colors cursor-pointer"
                  >
                    <Save className="w-4 h-4" />
                    <span>Save Profile Changes</span>
                  </button>
                </div>
              </form>
            )}

            {/* Security Tab */}
            {activeTab === 'security' && (
              <div className="space-y-6 text-xs sm:text-sm">
                <h3 className="font-extrabold text-gray-900 dark:text-white text-base border-b border-gray-100 dark:border-gray-800 pb-3 flex items-center gap-2">
                  <Shield className="w-5 h-5 text-indigo-500" />
                  <span>Session & Access Controls</span>
                </h3>

                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 rounded-xl bg-gray-50 dark:bg-[#161922] border border-gray-200 dark:border-gray-800">
                    <div className="flex items-center space-x-3">
                      <div className="p-2.5 rounded-xl bg-emerald-100 dark:bg-emerald-950/80 text-emerald-600 dark:text-emerald-400">
                        <Key className="w-6 h-6" />
                      </div>
                      <div>
                        <h4 className="font-bold text-gray-900 dark:text-white text-sm">Two-Factor Cryptographic Token</h4>
                        <p className="text-gray-500 dark:text-gray-400 text-xs mt-0.5">Hardware token authentication for high-risk override actions</p>
                      </div>
                    </div>
                    <span className="px-3 py-1 rounded-full bg-emerald-100 dark:bg-emerald-950/80 border border-emerald-300 dark:border-emerald-700 text-emerald-700 dark:text-emerald-400 text-xs font-bold">
                      ACTIVE
                    </span>
                  </div>

                  <div className="flex items-center justify-between p-4 rounded-xl bg-gray-50 dark:bg-[#161922] border border-gray-200 dark:border-gray-800">
                    <div className="flex items-center space-x-3">
                      <div className="p-2.5 rounded-xl bg-indigo-100 dark:bg-indigo-950/80 text-indigo-600 dark:text-indigo-400">
                        <Lock className="w-6 h-6" />
                      </div>
                      <div>
                        <h4 className="font-bold text-gray-900 dark:text-white text-sm">Automated Inactivity Lock</h4>
                        <p className="text-gray-500 dark:text-gray-400 text-xs mt-0.5">Lock console display after 15 minutes of zero operator input</p>
                      </div>
                    </div>
                    <input type="checkbox" defaultChecked className="w-5 h-5 rounded accent-indigo-600 cursor-pointer" />
                  </div>
                </div>
              </div>
            )}

            {/* Notifications Tab */}
            {activeTab === 'notifications' && (
              <div className="space-y-6 text-xs sm:text-sm">
                <h3 className="font-extrabold text-gray-900 dark:text-white text-base border-b border-gray-100 dark:border-gray-800 pb-3 flex items-center gap-2">
                  <Bell className="w-5 h-5 text-red-500" />
                  <span>Real-Time Threat Dispatch & Alarms</span>
                </h3>

                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 rounded-xl bg-gray-50 dark:bg-[#161922] border border-gray-200 dark:border-gray-800">
                    <div className="flex items-center space-x-3">
                      <div className="p-2.5 rounded-xl bg-red-100 dark:bg-red-950/80 text-red-600 dark:text-red-400">
                        <Bell className="w-6 h-6" />
                      </div>
                      <div>
                        <h4 className="font-bold text-gray-900 dark:text-white text-sm">Critical Breach Acoustic Alarm</h4>
                        <p className="text-gray-500 dark:text-gray-400 text-xs mt-0.5">Play audio acoustic alert when high-risk suspect is detected</p>
                      </div>
                    </div>
                    <input
                      type="checkbox"
                      checked={preferences.autoAlertSound}
                      onChange={(e) => setPreferences({ ...preferences, autoAlertSound: e.target.checked })}
                      className="w-5 h-5 rounded accent-indigo-600 cursor-pointer"
                    />
                  </div>

                  <div className="flex items-center justify-between p-4 rounded-xl bg-gray-50 dark:bg-[#161922] border border-gray-200 dark:border-gray-800">
                    <div className="flex items-center space-x-3">
                      <div className="p-2.5 rounded-xl bg-amber-100 dark:bg-amber-950/80 text-amber-600 dark:text-amber-400">
                        <Smartphone className="w-6 h-6" />
                      </div>
                      <div>
                        <h4 className="font-bold text-gray-900 dark:text-white text-sm">PCR Patrol Car Broadcast</h4>
                        <p className="text-gray-500 dark:text-gray-400 text-xs mt-0.5">Instant dispatch broadcast to nearest patrol units</p>
                      </div>
                    </div>
                    <input
                      type="checkbox"
                      checked={preferences.anprLiveIntercepts}
                      onChange={(e) => setPreferences({ ...preferences, anprLiveIntercepts: e.target.checked })}
                      className="w-5 h-5 rounded accent-indigo-600 cursor-pointer"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* System Preferences Tab */}
            {activeTab === 'system' && (
              <div className="space-y-6 text-xs sm:text-sm">
                <h3 className="font-extrabold text-gray-900 dark:text-white text-base border-b border-gray-100 dark:border-gray-800 pb-3 flex items-center gap-2">
                  <Monitor className="w-5 h-5 text-indigo-500" />
                  <span>Command Console Preferences</span>
                </h3>

                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 rounded-xl bg-gray-50 dark:bg-[#161922] border border-gray-200 dark:border-gray-800">
                    <div className="flex items-center space-x-3">
                      <div className="p-2.5 rounded-xl bg-indigo-100 dark:bg-indigo-950/80 text-indigo-600 dark:text-indigo-400">
                        <Monitor className="w-6 h-6" />
                      </div>
                      <div>
                        <h4 className="font-bold text-gray-900 dark:text-white text-sm">High-Contrast Surveillance Palette</h4>
                        <p className="text-gray-500 dark:text-gray-400 text-xs mt-0.5">Optimized for 24/7 command center monitor banks</p>
                      </div>
                    </div>
                    <span className="text-indigo-600 dark:text-indigo-400 font-mono font-bold text-xs">ACTIVE</span>
                  </div>

                  <div className="flex items-center justify-between p-4 rounded-xl bg-gray-50 dark:bg-[#161922] border border-gray-200 dark:border-gray-800">
                    <div className="flex items-center space-x-3">
                      <div className="p-2.5 rounded-xl bg-blue-100 dark:bg-blue-950/80 text-blue-600 dark:text-blue-400">
                        <Sliders className="w-6 h-6" />
                      </div>
                      <div>
                        <h4 className="font-bold text-gray-900 dark:text-white text-sm">Telemetry Audit Retention Window</h4>
                        <p className="text-gray-500 dark:text-gray-400 text-xs mt-0.5">Historical CCTV detection event retention period</p>
                      </div>
                    </div>
                    <span className="text-gray-900 dark:text-white font-mono font-bold">90 Days</span>
                  </div>
                </div>
              </div>
            )}

            {/* Camera Tab */}
            {activeTab === 'camera' && (
              <div className="space-y-6 text-xs sm:text-sm">
                <h3 className="font-extrabold text-gray-900 dark:text-white text-base border-b border-gray-100 dark:border-gray-800 pb-3 flex items-center gap-2">
                  <Video className="w-5 h-5 text-blue-500" />
                  <span>Neural Vision & Stream Codecs</span>
                </h3>

                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 rounded-xl bg-gray-50 dark:bg-[#161922] border border-gray-200 dark:border-gray-800">
                    <div className="flex items-center space-x-3">
                      <div className="p-2.5 rounded-xl bg-blue-100 dark:bg-blue-950/80 text-blue-600 dark:text-blue-400">
                        <Cpu className="w-6 h-6" />
                      </div>
                      <div>
                        <h4 className="font-bold text-gray-900 dark:text-white text-sm">AI Real-Time Optical Flow Processing</h4>
                        <p className="text-gray-500 dark:text-gray-400 text-xs mt-0.5">Enable hardware neural inferencing on all 4K PTZ streams</p>
                      </div>
                    </div>
                    <input
                      type="checkbox"
                      checked={preferences.neuralAutoScan}
                      onChange={(e) => setPreferences({ ...preferences, neuralAutoScan: e.target.checked })}
                      className="w-5 h-5 rounded accent-indigo-600 cursor-pointer"
                    />
                  </div>

                  <div className="flex items-center justify-between p-4 rounded-xl bg-gray-50 dark:bg-[#161922] border border-gray-200 dark:border-gray-800">
                    <div className="flex items-center space-x-3">
                      <div className="p-2.5 rounded-xl bg-emerald-100 dark:bg-emerald-950/80 text-emerald-600 dark:text-emerald-400">
                        <Video className="w-6 h-6" />
                      </div>
                      <div>
                        <h4 className="font-bold text-gray-900 dark:text-white text-sm">60 FPS Ultra-Low Latency Mode</h4>
                        <p className="text-gray-500 dark:text-gray-400 text-xs mt-0.5">Stream video at 60 frames per second using hardware acceleration</p>
                      </div>
                    </div>
                    <input
                      type="checkbox"
                      checked={preferences.cctvStreamFps60}
                      onChange={(e) => setPreferences({ ...preferences, cctvStreamFps60: e.target.checked })}
                      className="w-5 h-5 rounded accent-indigo-600 cursor-pointer"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>

          <SettingsBgSvg className="w-16 h-16 text-indigo-500" />
        </div>
      </div>
    </div>
  );
};
