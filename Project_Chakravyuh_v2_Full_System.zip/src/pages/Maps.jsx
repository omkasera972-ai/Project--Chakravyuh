import React, { useState, useEffect, useRef } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Polyline, Circle, useMap } from 'react-leaflet';
import L from 'leaflet';
import { useApp } from '../context/AppContext';
import { Video, AlertTriangle, Car, User, Shield, Layers, Search, Navigation, Compass, Radio, Target, RefreshCw } from 'lucide-react';

// Custom SVG map marker creators for system entities
const createCustomIcon = (color, type) => {
  return L.divIcon({
    className: 'custom-map-marker',
    html: `
      <div style="
        background-color: ${color};
        width: 26px;
        height: 26px;
        border-radius: 50%;
        border: 2px solid #ffffff;
        box-shadow: 0 0 10px rgba(0,0,0,0.8);
        display: flex;
        align-items: center;
        justify-content: center;
        color: #ffffff;
        font-size: 11px;
        font-weight: bold;
      ">
        ${type === 'cam' ? '📹' : type === 'veh' ? '🚗' : type === 'child' ? '🧒' : '⚠️'}
      </div>
    `,
    iconSize: [26, 26],
    iconAnchor: [13, 13],
    popupAnchor: [0, -13]
  });
};

// Google Maps-style Blue Dot Marker with Pulsing Ring for My Live Location
const googleBlueDotIcon = L.divIcon({
  className: 'google-blue-dot-marker',
  html: `
    <div style="position: relative; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center;">
      <div style="
        position: absolute;
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background-color: rgba(66, 133, 244, 0.35);
        border: 1px solid rgba(66, 133, 244, 0.7);
        animation: pulse 1.8s infinite;
      "></div>
      <div style="
        background: #4285F4;
        width: 18px;
        height: 18px;
        border-radius: 50%;
        border: 3px solid #ffffff;
        box-shadow: 0 0 12px rgba(66, 133, 244, 0.9);
        z-index: 10;
      "></div>
    </div>
  `,
  iconSize: [40, 40],
  iconAnchor: [20, 20],
  popupAnchor: [0, -20]
});

const camIcon = createCustomIcon('#2563eb', 'cam');
const alertIcon = createCustomIcon('#ef4444', 'alert');
const vehIcon = createCustomIcon('#eab308', 'veh');
const childIcon = createCustomIcon('#10b981', 'child');

// Component to dynamically pan & re-center map view
const RecenterMap = ({ center }) => {
  const map = useMap();
  useEffect(() => {
    if (center && Array.isArray(center) && center.length === 2 && center[0] && center[1]) {
      map.flyTo(center, 15, { duration: 1.5 });
    }
  }, [center, map]);
  return null;
};

export const Maps = () => {
  const { cameras, alerts, vehicles, missingChildren, setSelectedCameraForModal, showToast } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [activeLayers, setActiveLayers] = useState({
    myLiveLocation: true,
    cameras: true,
    alerts: true,
    vehicles: true,
    missingChildren: true
  });

  // Default Fallback Center (Indore City Center)
  const defaultCenter = [22.7250, 75.8650];
  const [mapCenter, setMapCenter] = useState(defaultCenter);

  // My Live Location State
  const [userLocation, setUserLocation] = useState({
    lat: null,
    lng: null,
    accuracy: 30,
    hasPermission: false,
    timestamp: null
  });
  const [locationError, setLocationError] = useState(null);
  const [addressName, setAddressName] = useState('');
  const initialCenteredRef = useRef(false);

  // Reverse Geocoding via OpenStreetMap Nominatim API
  const fetchAddressName = async (lat, lng) => {
    try {
      const res = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=14`, {
        headers: { 'Accept-Language': 'en' }
      });
      if (res.ok) {
        const data = await res.json();
        const city = data.address?.city || data.address?.town || data.address?.suburb || data.address?.village || data.address?.county || '';
        const state = data.address?.state || '';
        const formatted = `${city}${state ? `, ${state}` : ''}` || data.display_name?.split(',')[0] || 'Current Position';
        setAddressName(formatted);
      }
    } catch (err) {
      console.warn('Reverse geocode warning:', err);
    }
  };

  // Helper to handle Geolocation errors
  const handleLocationError = (err) => {
    console.warn('Geolocation Error:', err.message);
    if (err.code === 1) { // PERMISSION_DENIED
      setLocationError('Enable location access to see your live position');
    } else {
      setLocationError('Unable to lock GPS position. Check location settings.');
    }
  };

  // 1. Initial getCurrentPosition & 2. Continuous watchPosition on mount
  useEffect(() => {
    let watchId = null;

    const initGeolocation = () => {
      if (!('geolocation' in navigator)) {
        setLocationError('Geolocation API is not supported by your browser.');
        return;
      }

      // 1. Fetch initial position immediately on page load
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const lat = position.coords.latitude;
          const lng = position.coords.longitude;
          const accuracy = Math.round(position.coords.accuracy) || 25;

          setUserLocation({
            lat,
            lng,
            accuracy,
            hasPermission: true,
            timestamp: new Date().toLocaleTimeString()
          });
          setLocationError(null);

          // 5. Auto-center map on initial load
          if (!initialCenteredRef.current) {
            setMapCenter([lat, lng]);
            initialCenteredRef.current = true;
          }

          // 9. Reverse geocode coordinates to place name
          fetchAddressName(lat, lng);
        },
        (err) => {
          handleLocationError(err);
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 5000 }
      );

      // 2. Keep updating live position as user moves
      watchId = navigator.geolocation.watchPosition(
        (position) => {
          const lat = position.coords.latitude;
          const lng = position.coords.longitude;
          const accuracy = Math.round(position.coords.accuracy) || 25;

          setUserLocation(prev => ({
            ...prev,
            lat,
            lng,
            accuracy,
            hasPermission: true,
            timestamp: new Date().toLocaleTimeString()
          }));
          setLocationError(null);
        },
        (err) => {
          handleLocationError(err);
        },
        { enableHighAccuracy: true, maximumAge: 5000, timeout: 10000 }
      );
    };

    initGeolocation();

    // 8. Clean up geolocation watch on unmount
    return () => {
      if (watchId !== null && 'geolocation' in navigator) {
        navigator.geolocation.clearWatch(watchId);
      }
    };
  }, []);

  // 6. Recenter map to My Live Location
  const recenterToUser = () => {
    if (userLocation.lat && userLocation.lng) {
      setMapCenter([userLocation.lat, userLocation.lng]);
      showToast('Map Recentered', `Centered on My Live Location (${addressName || 'GPS Locked'})`, 'success');
    } else {
      retryPermissionRequest();
    }
  };

  // 7. Retry location permission request
  const retryPermissionRequest = () => {
    setLocationError(null);
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const lat = position.coords.latitude;
          const lng = position.coords.longitude;
          const accuracy = Math.round(position.coords.accuracy) || 25;

          setUserLocation({
            lat,
            lng,
            accuracy,
            hasPermission: true,
            timestamp: new Date().toLocaleTimeString()
          });
          setMapCenter([lat, lng]);
          setLocationError(null);
          fetchAddressName(lat, lng);
          showToast('Location Enabled', 'Live GPS position synced successfully!', 'success');
        },
        (err) => {
          handleLocationError(err);
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
      );
    }
  };

  const toggleLayer = (layer) => {
    setActiveLayers(prev => ({ ...prev, [layer]: !prev[layer] }));
  };

  const filteredCameras = cameras.filter(c => {
    const q = searchQuery.toLowerCase();
    return !searchQuery || c.name?.toLowerCase().includes(q) || c.code?.toLowerCase().includes(q) || c.zone?.toLowerCase().includes(q);
  });

  const filteredVehicles = vehicles.filter(v => {
    const q = searchQuery.toLowerCase();
    return !searchQuery || v.plate?.toLowerCase().includes(q) || v.type?.toLowerCase().includes(q) || v.reason?.toLowerCase().includes(q);
  });

  const filteredChildren = missingChildren.filter(ch => {
    const q = searchQuery.toLowerCase();
    return !searchQuery || ch.name?.toLowerCase().includes(q) || ch.lastSeenLocation?.toLowerCase().includes(q) || ch.id?.toLowerCase().includes(q);
  });

  return (
    <div className="space-y-4 select-none pb-6">
      {/* Location Permission Warning Banner (If Denied) */}
      {locationError && (
        <div className="bg-amber-500/15 border border-amber-500/40 text-amber-200 p-3.5 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs animate-in fade-in duration-200 shadow-md">
          <div className="flex items-center space-x-2.5">
            <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0" />
            <span className="font-semibold">{locationError}</span>
          </div>
          <button
            onClick={retryPermissionRequest}
            className="px-3.5 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center justify-center space-x-1.5 transition-all shadow-xs"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Retry Permission Request</span>
          </button>
        </div>
      )}

      {/* Header & Layer Filters */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 bg-[#111318] border border-[#21252f] p-4 rounded-xl shadow-lg">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-lg font-bold text-white tracking-tight">Geospatial Intelligence Map</h1>
            {userLocation.lat && (
              <span className="px-2.5 py-0.5 rounded-full bg-blue-500/20 text-blue-400 border border-blue-500/30 text-[10px] font-bold uppercase flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-blue-400 animate-ping" />
                Live Position Active
              </span>
            )}
          </div>
          <p className="text-xs text-neutral-400 mt-0.5">
            {addressName ? `📍 ${addressName} • Live Device Location` : 'Live surveillance topology, device GPS telemetry & incident mapping'}
          </p>
        </div>

        {/* Search Bar & Layer Toggles */}
        <div className="flex items-center space-x-2 flex-wrap gap-y-1.5">
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-neutral-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search map location / node..."
              className="pl-8 pr-3 py-1.5 bg-[#15171e] border border-[#252833] rounded-lg text-xs text-white placeholder-neutral-400 focus:outline-none focus:border-neutral-400"
            />
          </div>

          <button
            onClick={() => toggleLayer('myLiveLocation')}
            className={`px-2.5 py-1.5 rounded-lg text-xs font-medium border flex items-center space-x-1.5 transition-colors ${
              activeLayers.myLiveLocation
                ? 'bg-blue-600/20 text-blue-400 border-blue-500/40'
                : 'bg-[#15171e] text-neutral-500 border-[#252833]'
            }`}
          >
            <Navigation className="w-3.5 h-3.5" />
            <span>My Live Location</span>
          </button>

          <button
            onClick={() => toggleLayer('cameras')}
            className={`px-2.5 py-1.5 rounded-lg text-xs font-medium border flex items-center space-x-1.5 transition-colors ${
              activeLayers.cameras
                ? 'bg-blue-600/20 text-blue-400 border-blue-500/40'
                : 'bg-[#15171e] text-neutral-500 border-[#252833]'
            }`}
          >
            <Video className="w-3.5 h-3.5" />
            <span>Cameras ({cameras.length})</span>
          </button>

          <button
            onClick={() => toggleLayer('alerts')}
            className={`px-2.5 py-1.5 rounded-lg text-xs font-medium border flex items-center space-x-1.5 transition-colors ${
              activeLayers.alerts
                ? 'bg-red-600/20 text-red-400 border-red-500/40'
                : 'bg-[#15171e] text-neutral-500 border-[#252833]'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Alerts ({alerts.length})</span>
          </button>

          <button
            onClick={() => toggleLayer('vehicles')}
            className={`px-2.5 py-1.5 rounded-lg text-xs font-medium border flex items-center space-x-1.5 transition-colors ${
              activeLayers.vehicles
                ? 'bg-amber-600/20 text-amber-400 border-amber-500/40'
                : 'bg-[#15171e] text-neutral-500 border-[#252833]'
            }`}
          >
            <Car className="w-3.5 h-3.5" />
            <span>ANPR Routes ({vehicles.length})</span>
          </button>

          <button
            onClick={() => toggleLayer('missingChildren')}
            className={`px-2.5 py-1.5 rounded-lg text-xs font-medium border flex items-center space-x-1.5 transition-colors ${
              activeLayers.missingChildren
                ? 'bg-emerald-600/20 text-emerald-400 border-emerald-500/40'
                : 'bg-[#15171e] text-neutral-500 border-[#252833]'
            }`}
          >
            <User className="w-3.5 h-3.5" />
            <span>Missing Cases ({missingChildren.length})</span>
          </button>
        </div>
      </div>

      {/* Main Map Container */}
      <div className="bg-[#121419] border border-[#21242d] rounded-xl overflow-hidden shadow-2xl h-[calc(100vh-16rem)] min-h-[500px] relative">
        {/* 6. Floating Recenter (Crosshair) Button */}
        <button
          onClick={recenterToUser}
          title="Recenter Map to My Live Location"
          className="absolute top-4 right-4 z-20 w-10 h-10 rounded-xl bg-white dark:bg-[#121419] border border-gray-300 dark:border-[#272b36] shadow-xl flex items-center justify-center text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-[#1a1e28] transition-all cursor-pointer group active:scale-95"
        >
          <Target className="w-5 h-5 group-hover:scale-110 transition-transform" />
        </button>

        <MapContainer
          center={defaultCenter}
          zoom={13}
          style={{ width: '100%', height: '100%', background: '#ffffff' }}
          className="z-10"
        >
          {/* Re-center Map view dynamically */}
          <RecenterMap center={mapCenter} />

          {/* OpenStreetMap Real Light Basemap */}
          <TileLayer
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
          />

          {/* 3 & 4. MY LIVE LOCATION BLUE DOT MARKER & ACCURACY CIRCLE */}
          {activeLayers.myLiveLocation && userLocation.lat && userLocation.lng && (
            <React.Fragment key="my-live-location">
              {/* Accuracy Circle */}
              <Circle
                center={[userLocation.lat, userLocation.lng]}
                radius={userLocation.accuracy * 2}
                pathOptions={{
                  color: '#4285F4',
                  fillColor: '#4285F4',
                  fillOpacity: 0.15,
                  weight: 1
                }}
              />
              {/* Google Maps Blue Dot Marker */}
              <Marker position={[userLocation.lat, userLocation.lng]} icon={googleBlueDotIcon}>
                <Popup>
                  <div className="p-1 space-y-2 text-xs">
                    <div className="flex items-center justify-between border-b border-neutral-700 pb-1.5">
                      <div className="flex items-center space-x-1.5">
                        <span className="w-2.5 h-2.5 rounded-full bg-blue-500 animate-ping" />
                        <strong className="text-white text-sm block">My Live Location</strong>
                      </div>
                      <span className="px-2 py-0.5 rounded bg-blue-600 text-white font-mono text-[10px] font-bold">
                        GPS TRACKING
                      </span>
                    </div>

                    <div className="space-y-1 text-neutral-300">
                      {addressName && (
                        <p className="font-bold text-blue-300 text-xs">📍 {addressName}</p>
                      )}
                      <p className="font-mono text-[11px]">
                        {userLocation.lat.toFixed(5)}° N, {userLocation.lng.toFixed(5)}° E
                      </p>
                      <p className="text-[10px] text-neutral-400">
                        Accuracy Margin: ±{userLocation.accuracy} meters • Updated: {userLocation.timestamp}
                      </p>
                    </div>

                    <button
                      onClick={recenterToUser}
                      className="w-full mt-1 py-1 px-2 rounded bg-blue-600 hover:bg-blue-500 text-white text-[11px] font-semibold flex items-center justify-center space-x-1"
                    >
                      <Target className="w-3 h-3" />
                      <span>Recenter View</span>
                    </button>
                  </div>
                </Popup>
              </Marker>
            </React.Fragment>
          )}

          {/* Camera Markers */}
          {activeLayers.cameras && filteredCameras.map((cam) => (
            <Marker key={cam.id} position={[cam.lat, cam.lng]} icon={camIcon}>
              <Popup>
                <div className="p-1 space-y-2 text-xs">
                  <div className="flex justify-between items-center border-b border-neutral-700 pb-1">
                    <strong className="text-white text-sm">{cam.code}</strong>
                    <span className="text-[10px] text-emerald-400 font-bold">{cam.status}</span>
                  </div>
                  <p className="text-neutral-300">{cam.zone}</p>
                  <p className="text-neutral-400 font-mono text-[10px]">{cam.type}</p>
                  <button
                    onClick={() => setSelectedCameraForModal(cam)}
                    className="w-full mt-1 py-1 px-2 rounded bg-neutral-800 hover:bg-neutral-700 text-white text-[11px] font-semibold border border-neutral-600"
                  >
                    Open Live Video Feed
                  </button>
                </div>
              </Popup>
            </Marker>
          ))}

          {/* ANPR Vehicle Routes & Intercept Markers */}
          {activeLayers.vehicles && filteredVehicles.map((veh) => (
            <React.Fragment key={veh.id}>
              <Polyline
                positions={veh.route}
                color={veh.status === 'Blacklisted' ? '#ef4444' : '#f59e0b'}
                dashArray={veh.status === 'Blacklisted' ? '6, 6' : null}
                weight={3}
                opacity={0.85}
              />
              <Marker position={veh.route[veh.route.length - 1]} icon={vehIcon}>
                <Popup>
                  <div className="p-1 space-y-1.5 text-xs">
                    <strong className="text-white font-mono block text-sm">{veh.plate}</strong>
                    <p className="text-neutral-300 font-medium">{veh.type}</p>
                    <p className="text-red-400 font-bold">{veh.status} • {veh.speed}</p>
                    <p className="text-neutral-400 text-[10px]">{veh.reason}</p>
                  </div>
                </Popup>
              </Marker>
            </React.Fragment>
          ))}

          {/* Missing Children Last Seen & Search Radius */}
          {activeLayers.missingChildren && filteredChildren.map((child) => (
            <React.Fragment key={child.id}>
              <Circle
                center={[child.lat, child.lng]}
                radius={800}
                pathOptions={{ color: '#10b981', fillColor: '#10b981', fillOpacity: 0.15 }}
              />
              <Marker position={[child.lat, child.lng]} icon={childIcon}>
                <Popup>
                  <div className="p-1 space-y-1.5 text-xs">
                    <strong className="text-white block text-sm">{child.name} ({child.age} yrs)</strong>
                    <p className="text-emerald-400 font-bold">{child.status}</p>
                    <p className="text-neutral-300">{child.lastSeenLocation}</p>
                    <p className="text-neutral-400 text-[10px] italic">{child.description}</p>
                  </div>
                </Popup>
              </Marker>
            </React.Fragment>
          ))}
        </MapContainer>

        {/* Legend Overlay at Bottom-Left */}
        <div className="absolute bottom-4 left-4 z-20 bg-[#121419]/90 backdrop-blur-md border border-[#272b36] p-3 rounded-lg text-xs space-y-1.5 text-neutral-300 shadow-xl">
          <span className="font-bold text-white text-[11px] uppercase tracking-wider block border-b border-[#232731] pb-1">
            Map Overlay Legend
          </span>
          <div className="flex items-center space-x-2">
            <span className="w-3 h-3 rounded-full bg-[#4285F4] border-2 border-white animate-pulse" />
            <span className="font-bold text-blue-400">My Live Location (Blue Dot)</span>
          </div>
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-500" />
            <span>Active CCTV Node</span>
          </div>
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-yellow-500" />
            <span>ANPR Vehicle Trail</span>
          </div>
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
            <span>Missing Child Search Zone</span>
          </div>
        </div>
      </div>
    </div>
  );
};
