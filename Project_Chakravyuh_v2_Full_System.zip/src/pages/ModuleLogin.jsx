import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { MODULES_DATA } from './PurposeSelector';
import {
  Shield,
  Lock,
  User,
  ArrowLeft,
  CheckCircle2,
  Sparkles,
  BadgeCheck,
  UserPlus,
  LogIn,
  Eye,
  EyeOff,
  Mail,
  School,
  GraduationCap,
  Landmark,
  Building2,
  ShieldAlert,
  Car,
  Heart,
  Cpu,
  UserCheck
} from 'lucide-react';

const SUB_CATEGORIES_MAP = {
  'attendance': [
    { id: 'Govt Higher School', title: 'Govt Higher School', desc: 'Principals, Teachers & Staff', icon: School },
    { id: 'Govt Degree College', title: 'Govt Degree College', desc: 'Deans, HODs & Professors', icon: GraduationCap },
    { id: 'State / Central Univ', title: 'State / Central Univ', desc: 'VC Office & Campus Admin', icon: Landmark },
    { id: 'Govt Enterprise HQ', title: 'Govt Enterprise HQ', desc: 'HR, Officers & Staff Roster', icon: Building2 }
  ],
  'criminal-tracking': [
    { id: 'State Police HQ', title: 'State Police HQ', desc: 'DGP, SP & Station Incharge', icon: Shield },
    { id: 'Crime Branch CID', title: 'Crime Branch & CID', desc: 'Investigating Officers & Forensics', icon: UserCheck },
    { id: 'Highway Patrol PCR', title: 'Highway Patrol PCR', desc: 'Patrol Sergeant & Intercepts', icon: ShieldAlert },
    { id: 'Anti-Terror Intel', title: 'Intel & Watchlist Desk', desc: 'National Threat Intelligence', icon: Cpu }
  ],
  'anpr': [
    { id: 'State Traffic Command', title: 'State Traffic Command', desc: 'Traffic SP & Speed Enforcement', icon: Shield },
    { id: 'Expressway Toll', title: 'Expressway Toll Corridor', desc: 'Toll Ops & LPR Readers', icon: Car },
    { id: 'Stolen Vehicle Cell', title: 'Stolen Vehicle Recovery', desc: 'RTO Inspector & Vehicle Hotlist', icon: ShieldAlert },
    { id: 'Smart City Challan', title: 'Smart City Challan Hub', desc: 'Automated Ticket Dispatch', icon: Building2 }
  ],
  'missing-child': [
    { id: 'Anti-Trafficking Cell', title: 'Anti-Trafficking Cell', desc: 'CWC Officers & Police Lead', icon: Heart },
    { id: 'Public Hospital Desk', title: 'Public Hospital Desk', desc: 'Childline Coordinators', icon: Landmark },
    { id: 'Transit Patrol Unit', title: 'Transit Patrol Unit', desc: 'Railway & Bus Terminal Ops', icon: Shield },
    { id: 'Parent Guardian Desk', title: 'Parent Guardian Desk', desc: 'Direct Family Case Filing', icon: User }
  ],
  'defence': [
    { id: 'Garrison Command', title: 'Garrison Command Bunker', desc: 'Brigade Commander & Ops Room', icon: Shield },
    { id: 'Airbase Security', title: 'Airbase Security Guard', desc: 'Armory Vault & Depot Clearance', icon: Lock },
    { id: 'Border Outpost RADAR', title: 'Border Thermal RADAR', desc: 'Border Outpost & Thermal Mesh', icon: Cpu },
    { id: 'Tactical QRT Unit', title: 'Tactical QRT Mobile', desc: 'QRT Field Patrol Telemetry', icon: ShieldAlert }
  ]
};

export const ModuleLogin = () => {
  const { moduleId } = useParams();
  const navigate = useNavigate();
  const { loginModule, showToast } = useApp();

  const module = MODULES_DATA.find(m => m.id === moduleId) || MODULES_DATA[0];
  const IconComponent = module.icon;
  const subCategories = SUB_CATEGORIES_MAP[module.id] || SUB_CATEGORIES_MAP['criminal-tracking'];

  const [activeTab, setActiveTab] = useState('login'); // 'login' | 'register'
  const [selectedSubCategory, setSelectedSubCategory] = useState(subCategories[0].id);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('admin123');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // Registration states
  const [regFullName, setRegFullName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');

  // Auto set subcategory when module changes
  useEffect(() => {
    const cats = SUB_CATEGORIES_MAP[module.id] || SUB_CATEGORIES_MAP['criminal-tracking'];
    setSelectedSubCategory(cats[0].id);
    setUsername(`Officer_${cats[0].id.replace(/\s+/g, '_')}`);
  }, [module.id]);

  const handleSubCategorySelect = (catId) => {
    setSelectedSubCategory(catId);
    setUsername(`Officer_${catId.replace(/\s+/g, '_')}`);
  };

  const handleLoginSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      // Call FastAPI Backend Auth Login
      const res = await fetch('http://127.0.0.1:8000/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          moduleId: module.id,
          username: username || `Officer_${selectedSubCategory}`,
          password: password || 'admin123',
          subCategory: selectedSubCategory
        })
      }).catch(() => null);

      let userData = {
        name: username || `${selectedSubCategory} Authorized Officer`,
        role: selectedSubCategory,
        badge: `BADGE-${module.id.toUpperCase().slice(0, 4)}-2026`,
        moduleId: module.id,
        subCategory: selectedSubCategory
      };

      if (res && res.ok) {
        const data = await res.json();
        if (data.user) {
          userData = data.user;
        }
      }

      loginModule(module.id, userData);
      showToast('Access Authorized', `Authenticated for ${selectedSubCategory} (${module.title})`, 'success');
      navigate(`/portal/${module.id}/dashboard`);
    } catch (err) {
      console.error(err);
      loginModule(module.id, {
        name: username || `${selectedSubCategory} Authorized Officer`,
        role: selectedSubCategory,
        badge: `BADGE-${module.id.toUpperCase().slice(0, 4)}-2026`,
        moduleId: module.id,
        subCategory: selectedSubCategory
      });
      navigate(`/portal/${module.id}/dashboard`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleSignIn = () => {
    setIsLoading(true);
    setTimeout(() => {
      loginModule(module.id, {
        name: `${selectedSubCategory} Admin (Google SSO)`,
        role: selectedSubCategory,
        badge: `BADGE-${module.id.toUpperCase().slice(0, 4)}-GOOG`,
        email: 'officer.admin@gmail.com',
        moduleId: module.id,
        subCategory: selectedSubCategory
      });
      showToast('Google Sign-In Successful', `Signed in as officer.admin@gmail.com for ${selectedSubCategory}`, 'success');
      navigate(`/portal/${module.id}/dashboard`);
    }, 500);
  };

  const handleRegisterSubmit = async (e) => {
    e.preventDefault();
    if (!regFullName || !regEmail) {
      showToast('Registration Error', 'Please fill in all required fields.', 'error');
      return;
    }
    setIsLoading(true);

    try {
      await fetch('http://127.0.0.1:8000/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          moduleId: module.id,
          fullName: regFullName,
          email: regEmail,
          password: regPassword,
          subCategory: selectedSubCategory
        })
      }).catch(() => null);

      showToast('Account Registered', `Registered ${regFullName} for ${selectedSubCategory}`, 'success');
      setActiveTab('login');
      setUsername(regFullName);
    } catch (err) {
      showToast('Registration Successful', `Account registered for ${regFullName}`, 'success');
      setActiveTab('login');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDemoLogin = () => {
    loginModule(module.id, {
      name: `${selectedSubCategory} Clearance Lead`,
      role: selectedSubCategory,
      badge: `BADGE-${module.id.toUpperCase().slice(0, 4)}-DEMO`,
      moduleId: module.id,
      subCategory: selectedSubCategory
    });
    showToast('Demo Clearance Activated', `Granted full administrative clearance to ${selectedSubCategory}`, 'info');
    navigate(`/portal/${module.id}/dashboard`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 via-white to-slate-100/90 text-slate-900 flex flex-col justify-between selection:bg-indigo-600 selection:text-white font-sans antialiased relative overflow-x-hidden">
      
      {/* Background Decorative Mesh */}
      <div className="absolute -top-32 -left-32 w-96 h-96 bg-indigo-200/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-1/2 -right-32 w-[500px] h-[500px] bg-blue-200/15 rounded-full blur-3xl pointer-events-none" />

      {/* Top Header Bar — FIXED AT TOP (NEVER SCROLLS) */}
      <header className="fixed top-0 left-0 right-0 z-50 w-full border-b border-slate-200 bg-white/95 backdrop-blur-2xl px-6 sm:px-12 py-4 shadow-sm">
        <div className="w-full flex items-center justify-between">
          <button
            onClick={() => navigate('/')}
            className="flex items-center gap-2.5 text-xs sm:text-sm font-black text-slate-800 hover:text-indigo-600 transition-colors bg-slate-100 hover:bg-slate-200 px-5 py-2.5 rounded-2xl border-2 border-slate-200/90 cursor-pointer shadow-xs"
          >
            <ArrowLeft className="w-4 h-4 stroke-[3]" />
            <span>Back to Purpose Selector</span>
          </button>

          <div className="flex items-center gap-3">
            <span className="text-xs sm:text-sm font-extrabold text-slate-500 hidden sm:inline">Active Domain:</span>
            <span className={`text-xs sm:text-sm font-black px-4 py-1.5 rounded-full border-2 ${module.badgeBg} shadow-xs flex items-center gap-2`}>
              <span>{module.title}</span>
            </span>
          </div>
        </div>
      </header>

      {/* Main Login Form Container */}
      <main className="flex-grow max-w-2xl w-full mx-auto px-6 pt-28 pb-12 flex flex-col justify-center relative z-10">
        <div className="bg-white border-2 border-slate-200/90 rounded-[2.5rem] p-8 sm:p-12 shadow-2xl relative overflow-hidden text-slate-900">
          
          {/* Module Icon & Title Header */}
          <div className="text-center space-y-4 mb-7 relative z-10">
            <div className={`w-20 h-20 rounded-3xl bg-gradient-to-tr ${module.gradient} flex items-center justify-center mx-auto shadow-xl text-white transform hover:scale-105 transition-transform`}>
              <IconComponent className="w-10 h-10 stroke-[2.5]" />
            </div>
            <div>
              <span className={`text-xs font-black tracking-widest uppercase px-4 py-1.5 rounded-full border-2 ${module.badgeBg}`}>
                {module.badge} Portal Access
              </span>
              <h2 className="text-3xl sm:text-4xl font-black text-slate-950 mt-3 tracking-tight">
                Sign In to {module.title}
              </h2>
              <p className="text-sm sm:text-base font-bold text-slate-500 mt-1">
                Select your domain sector, sign in with Google, or enter your credentials.
              </p>
            </div>
          </div>

          {/* DYNAMIC SUB-CATEGORY DOMAIN SELECTOR FOR ALL 5 MODULES */}
          <div className="mb-7 p-5 bg-gradient-to-br from-slate-50 via-indigo-50/40 to-blue-50/40 rounded-3xl border-2 border-slate-200 shadow-xs space-y-3">
            <label className="block text-xs font-black text-slate-800 uppercase tracking-wider flex items-center gap-2">
              <Shield className="w-4 h-4 text-indigo-600 stroke-[2.5]" />
              <span>Select {module.title} Sector Category:</span>
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {subCategories.map((cat) => {
                const CatIcon = cat.icon;
                const isSelected = selectedSubCategory === cat.id;
                return (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => handleSubCategorySelect(cat.id)}
                    className={`p-3.5 rounded-2xl border-2 text-left transition-all cursor-pointer flex items-center gap-3 ${
                      isSelected
                        ? 'bg-white border-indigo-600 shadow-md ring-2 ring-indigo-500/20'
                        : 'bg-white/80 border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold shrink-0 ${
                      isSelected ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-600'
                    }`}>
                      <CatIcon className="w-5 h-5 stroke-[2.5]" />
                    </div>
                    <div>
                      <h4 className="text-xs sm:text-sm font-black text-slate-900 leading-snug">{cat.title}</h4>
                      <p className="text-[11px] font-extrabold text-slate-500 leading-snug">{cat.desc}</p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Login / Register Toggle Tabs */}
          <div className="grid grid-cols-2 p-1.5 bg-slate-100 rounded-2xl border-2 border-slate-200 mb-7 text-xs sm:text-sm font-black">
            <button
              type="button"
              onClick={() => setActiveTab('login')}
              className={`py-3 rounded-xl flex items-center justify-center gap-2.5 transition-all cursor-pointer ${
                activeTab === 'login'
                  ? 'bg-slate-900 text-white shadow-md'
                  : 'text-slate-600 hover:text-slate-950'
              }`}
            >
              <LogIn className="w-4 h-4 stroke-[2.5]" />
              <span>Sign In</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('register')}
              className={`py-3 rounded-xl flex items-center justify-center gap-2.5 transition-all cursor-pointer ${
                activeTab === 'register'
                  ? 'bg-slate-900 text-white shadow-md'
                  : 'text-slate-600 hover:text-slate-950'
              }`}
            >
              <UserPlus className="w-4 h-4 stroke-[2.5]" />
              <span>Register Account</span>
            </button>
          </div>

          {activeTab === 'login' ? (
            <div className="space-y-6">
              {/* GOOGLE SIGN IN BUTTON */}
              <button
                type="button"
                onClick={handleGoogleSignIn}
                disabled={isLoading}
                className="w-full py-4 px-5 bg-white border-2 border-slate-200 hover:border-slate-300 hover:bg-slate-50 text-slate-900 font-black rounded-2xl transition-all shadow-sm flex items-center justify-center gap-3 cursor-pointer text-sm sm:text-base group"
              >
                <svg className="w-5 h-5" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
                <span>Sign in with Google ({selectedSubCategory})</span>
              </button>

              <div className="relative my-6 text-center">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t-2 border-slate-200" />
                </div>
                <span className="relative bg-white px-4 text-xs font-black text-slate-400 uppercase tracking-wider">
                  Or continue with email
                </span>
              </div>

              {/* Sign In Form */}
              <form onSubmit={handleLoginSubmit} className="space-y-5">
                <div>
                  <label className="block text-xs font-black text-slate-700 uppercase tracking-wider mb-2">
                    Email / Officer Username
                  </label>
                  <div className="relative">
                    <User className="w-5 h-5 text-slate-400 absolute left-4 top-3.5 stroke-[2.5]" />
                    <input
                      type="text"
                      required
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      placeholder={`e.g. Officer_${selectedSubCategory.replace(/\s+/g, '_')}`}
                      className="w-full bg-slate-50 border-2 border-slate-200 focus:border-indigo-600 focus:bg-white rounded-2xl pl-12 pr-4 py-3.5 text-sm sm:text-base font-bold text-slate-900 placeholder-slate-400 focus:outline-none transition-all shadow-xs"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-black text-slate-700 uppercase tracking-wider mb-2">
                    Password
                  </label>
                  <div className="relative">
                    <Lock className="w-5 h-5 text-slate-400 absolute left-4 top-3.5 stroke-[2.5]" />
                    <input
                      type={showPassword ? "text" : "password"}
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••••••"
                      className="w-full bg-slate-50 border-2 border-slate-200 focus:border-indigo-600 focus:bg-white rounded-2xl pl-12 pr-12 py-3.5 text-sm sm:text-base font-bold text-slate-900 placeholder-slate-400 focus:outline-none transition-all shadow-xs"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-4 top-3.5 text-slate-400 hover:text-slate-700 transition-colors cursor-pointer"
                    >
                      {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-4 bg-slate-900 hover:bg-slate-800 rounded-2xl text-sm sm:text-base font-black text-white flex items-center justify-center gap-3 transition-all cursor-pointer shadow-xl"
                >
                  {isLoading ? (
                    <span>Authenticating...</span>
                  ) : (
                    <>
                      <BadgeCheck className="w-5 h-5 stroke-[2.5]" />
                      <span>Authorize & Sign In ({selectedSubCategory})</span>
                    </>
                  )}
                </button>
              </form>

              {/* Quick 1-Click Instant Demo Button */}
              <button
                type="button"
                onClick={handleDemoLogin}
                className="w-full py-3.5 bg-slate-100 hover:bg-slate-200 border-2 border-slate-200 text-slate-800 rounded-2xl text-xs sm:text-sm font-black flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <Sparkles className="w-4 h-4 text-amber-600" />
                <span>One-Click Instant Demo Access ({selectedSubCategory})</span>
              </button>
            </div>
          ) : (
            /* Registration Form */
            <form onSubmit={handleRegisterSubmit} className="space-y-5">
              <div>
                <label className="block text-xs font-black text-slate-700 uppercase tracking-wider mb-2">
                  Full Name
                </label>
                <div className="relative">
                  <User className="w-5 h-5 text-slate-400 absolute left-4 top-3.5 stroke-[2.5]" />
                  <input
                    type="text"
                    required
                    value={regFullName}
                    onChange={(e) => setRegFullName(e.target.value)}
                    placeholder="Officer Full Name"
                    className="w-full bg-slate-50 border-2 border-slate-200 focus:border-indigo-600 focus:bg-white rounded-2xl pl-12 pr-4 py-3.5 text-sm font-bold text-slate-900 placeholder-slate-400 focus:outline-none transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-black text-slate-700 uppercase tracking-wider mb-2">
                  Official Email Address
                </label>
                <div className="relative">
                  <Mail className="w-5 h-5 text-slate-400 absolute left-4 top-3.5 stroke-[2.5]" />
                  <input
                    type="email"
                    required
                    value={regEmail}
                    onChange={(e) => setRegEmail(e.target.value)}
                    placeholder="officer@domain.com"
                    className="w-full bg-slate-50 border-2 border-slate-200 focus:border-indigo-600 focus:bg-white rounded-2xl pl-12 pr-4 py-3.5 text-sm font-bold text-slate-900 placeholder-slate-400 focus:outline-none transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-black text-slate-700 uppercase tracking-wider mb-2">
                  Set Password
                </label>
                <div className="relative">
                  <Lock className="w-5 h-5 text-slate-400 absolute left-4 top-3.5 stroke-[2.5]" />
                  <input
                    type="password"
                    required
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    placeholder="••••••••••••"
                    className="w-full bg-slate-50 border-2 border-slate-200 focus:border-indigo-600 focus:bg-white rounded-2xl pl-12 pr-4 py-3.5 text-sm font-bold text-slate-900 placeholder-slate-400 focus:outline-none transition-all"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-4 bg-slate-900 hover:bg-slate-800 rounded-2xl text-sm sm:text-base font-black text-white flex items-center justify-center gap-2.5 transition-all shadow-xl cursor-pointer mt-2"
              >
                <UserPlus className="w-5 h-5 stroke-[2.5]" />
                <span>Create Account ({selectedSubCategory})</span>
              </button>
            </form>
          )}

          {/* Security Badge Footer */}
          <div className="mt-8 pt-6 border-t-2 border-slate-100 text-center">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-slate-100 border border-slate-200 text-slate-600 text-xs font-extrabold">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>256-Bit Encrypted Session • Authorized Personnel Only</span>
            </div>
          </div>

        </div>
      </main>

      {/* Footer Bar */}
      <footer className="text-center text-xs sm:text-sm font-extrabold text-slate-500 border-t-2 border-slate-200 py-6 px-8 bg-white/90 backdrop-blur-md relative z-10">
        <p>© 2026 Project Chakravyuh — Smart Security & Surveillance Command System. All 5 Feature Portals Active.</p>
      </footer>
    </div>
  );
};

export default ModuleLogin;
