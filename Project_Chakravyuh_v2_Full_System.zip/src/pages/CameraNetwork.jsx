import React, { useState } from 'react';
import { Video, Grid, List, Activity, ShieldCheck, AlertTriangle, Eye, Search } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { StatCard } from '../components/StatCard';
import { CctvView } from '../components/CctvView';

export const CameraNetwork = () => {
  const { cameras, setSelectedCameraForModal, toggleCameraStatus } = useApp();
  const [viewMode, setViewMode] = useState('grid'); // 'grid' | 'table'
  const [filterStatus, setFilterStatus] = useState('All');
  const [searchTerm, setSearchTerm] = useState('');

  const totalCameras = cameras.length;
  const onlineCameras = cameras.filter(c => c.status === 'Online').length;
  const offlineCameras = cameras.filter(c => c.status === 'Offline').length;

  const filteredCameras = cameras.filter(c => {
    const matchesStatus = filterStatus === 'All' || c.status === filterStatus;
    const q = searchTerm.toLowerCase();
    const matchesSearch = c.name?.toLowerCase().includes(q) ||
                          c.code?.toLowerCase().includes(q) ||
                          c.zone?.toLowerCase().includes(q) ||
                          c.type?.toLowerCase().includes(q) ||
                          c.id?.toLowerCase().includes(q);
    return matchesStatus && matchesSearch;
  });

  return (
    <div className="space-y-4 select-none pb-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 bg-[#111318] border border-[#21252f] p-4 rounded-xl">
        <div>
          <h1 className="text-lg font-bold text-white tracking-tight">Camera Network Management</h1>
          <p className="text-xs text-neutral-400">Citywide CCTV nodes, PTZ controls, neural stream analyzers & status health</p>
        </div>

        <div className="flex items-center space-x-3">
          <div className="flex items-center bg-[#171922] p-1 rounded-lg border border-[#272b35]">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-1.5 rounded-md ${viewMode === 'grid' ? 'bg-[#222631] text-white' : 'text-neutral-400 hover:text-white'}`}
            >
              <Grid className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('table')}
              className={`p-1.5 rounded-md ${viewMode === 'table' ? 'bg-[#222631] text-white' : 'text-neutral-400 hover:text-white'}`}
            >
              <List className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* KPI Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5">
        <StatCard title="Total Connected Nodes" value={String(totalCameras)} subtext="City Grid" icon={Video} />
        <StatCard title="Online Streams" value={String(onlineCameras)} subtext="Streaming Live" icon={ShieldCheck} />
        <StatCard title="Offline Nodes" value={String(offlineCameras)} subtext="Maintenance Needed" icon={AlertTriangle} />
        <StatCard title="Average Latency" value="18 ms" subtext="RTSP Low Latency" icon={Activity} />
      </div>

      {/* Filter Tabs & Search Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
        <div className="flex items-center space-x-2">
          {['All', 'Online', 'Offline'].map(status => (
            <button
              key={status}
              onClick={() => setFilterStatus(status)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                filterStatus === status
                  ? 'bg-white text-black font-semibold'
                  : 'bg-[#14161d] text-neutral-400 border border-[#242833] hover:text-white'
              }`}
            >
              {status} Cameras ({status === 'All' ? totalCameras : status === 'Online' ? onlineCameras : offlineCameras})
            </button>
          ))}
        </div>

        <div className="relative">
          <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-neutral-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search camera name, code, zone..."
            className="pl-8 pr-3 py-1.5 bg-[#14161d] border border-[#242833] rounded-lg text-xs text-white placeholder-neutral-400 focus:outline-none focus:border-neutral-400"
          />
        </div>
      </div>

      {/* Grid View */}
      {viewMode === 'grid' ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
          {filteredCameras.map((cam) => (
            <div
              key={cam.id}
              className="bg-[#121419] border border-[#21242d] rounded-xl p-3.5 space-y-3 flex flex-col justify-between hover:border-neutral-500 transition-all group"
            >
              <div>
                <CctvView
                  cameraCode={cam.code}
                  location={cam.name}
                  isLive={cam.status === 'Online'}
                  aspectRatio="aspect-[16/10]"
                  onClick={() => setSelectedCameraForModal(cam)}
                />
                <div className="mt-3 flex items-start justify-between">
                  <div>
                    <h3 className="font-bold text-white text-xs leading-tight">{cam.name}</h3>
                    <p className="text-[11px] text-neutral-400 mt-0.5">{cam.zone}</p>
                  </div>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                    cam.status === 'Online'
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                      : 'bg-red-500/20 text-red-400 border border-red-500/30'
                  }`}>
                    {cam.status}
                  </span>
                </div>
              </div>

              <div className="pt-2 border-t border-[#1e222b] flex items-center justify-between text-xs">
                <span className="text-[11px] text-neutral-500 font-mono">{cam.type}</span>
                <button
                  onClick={() => setSelectedCameraForModal(cam)}
                  className="px-2 py-1 bg-[#191b22] border border-[#272b36] rounded text-neutral-200 hover:text-white hover:border-neutral-400 text-[11px]"
                >
                  Inspect Feed
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* Table View */
        <div className="bg-[#121419] border border-[#21242d] rounded-xl p-4">
          <div className="overflow-x-auto rounded-lg border border-[#21242d]">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-[#171922] border-b border-[#21242d] text-neutral-400 font-semibold uppercase tracking-wider text-[11px]">
                  <th className="py-2.5 px-3">Camera ID</th>
                  <th className="py-2.5 px-3">Location & Zone</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3">Hardware Type</th>
                  <th className="py-2.5 px-3">Resolution</th>
                  <th className="py-2.5 px-3">Telemetry / Activity</th>
                  <th className="py-2.5 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1c1f28]">
                {filteredCameras.map((cam) => (
                  <tr key={cam.id} className="hover:bg-[#161820] transition-colors">
                    <td className="py-2.5 px-3 font-mono font-bold text-white">{cam.id}</td>
                    <td className="py-2.5 px-3">
                      <span className="font-medium text-white block">{cam.name}</span>
                      <span className="text-[10px] text-neutral-400">{cam.zone}</span>
                    </td>
                    <td className="py-2.5 px-3">
                      <span className={`px-2 py-0.5 rounded font-semibold text-[10px] ${
                        cam.status === 'Online'
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          : 'bg-red-500/20 text-red-400 border border-red-500/30'
                      }`}>
                        {cam.status}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-neutral-300">{cam.type}</td>
                    <td className="py-2.5 px-3 font-mono text-neutral-400">{cam.resolution}</td>
                    <td className="py-2.5 px-3 text-neutral-300">{cam.lastActivity}</td>
                    <td className="py-2.5 px-3 text-right space-x-2">
                      <button
                        onClick={() => toggleCameraStatus(cam.id)}
                        className="px-2 py-1 rounded bg-[#1f222b] hover:bg-neutral-700 text-neutral-300 hover:text-white text-[11px]"
                      >
                        Toggle Status
                      </button>
                      <button
                        onClick={() => setSelectedCameraForModal(cam)}
                        className="px-2.5 py-1 rounded bg-white text-black font-semibold hover:bg-neutral-200 text-[11px]"
                      >
                        Inspect
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
