import React, { useState, useRef, useEffect } from 'react';
import * as faceapi from '@vladmandic/face-api';
import { jsPDF } from 'jspdf';
import {
  UserCheck,
  Users,
  UserX,
  Clock,
  UserPlus,
  CheckCircle2,
  Search,
  Camera,
  RefreshCw,
  X,
  Download,
  FileText,
  FileSpreadsheet,
  Info
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { StatCard } from '../components/StatCard';

let modelsLoaded = false;
let modelLoadingPromise = null;

const FACE_DISTANCE_THRESHOLD = 0.5;
const TWELVE_HOURS_MS = 12 * 60 * 60 * 1000; // 12 Hours in milliseconds

const loadFaceModels = async () => {
  if (modelsLoaded) return true;
  if (!modelLoadingPromise) {
    modelLoadingPromise = (async () => {
      try {
        const MODEL_URL = '/models';
        await Promise.all([
          faceapi.nets.ssdMobilenetv1.loadFromUri(MODEL_URL),
          faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL),
          faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL),
          faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL)
        ]);
        modelsLoaded = true;
        return true;
      } catch (err) {
        console.error('AI Face Models loading error:', err);
        modelsLoaded = false;
        return false;
      }
    })();
  }
  return modelLoadingPromise;
};

const loadImageElement = (imageDataUrl) => {
  return new Promise((resolve) => {
    if (!imageDataUrl) return resolve(null);
    if (typeof imageDataUrl !== 'string') return resolve(imageDataUrl);
    const img = new Image();
    if (imageDataUrl.startsWith('http://') || imageDataUrl.startsWith('https://')) {
      img.crossOrigin = 'Anonymous';
    }
    img.onload = () => resolve(img);
    img.onerror = () => resolve(null);
    img.src = imageDataUrl;
  });
};

const detectAndExtractFaceDescriptor = async (imageDataUrl) => {
  try {
    const isReady = await loadFaceModels();
    if (!isReady) {
      return { faceCount: 0, hasFace: false, faces: [], descriptor: null, error: 'AI Face Models Failed to Load' };
    }
    const imgElement = await loadImageElement(imageDataUrl);
    if (!imgElement) return { faceCount: 0, hasFace: false, faces: [], descriptor: null };

    let detections = await faceapi
      .detectAllFaces(imgElement, new faceapi.SsdMobilenetv1Options({ minConfidence: 0.2, maxResults: 20 }))
      .withFaceLandmarks()
      .withFaceDescriptors();

    if (detections.length === 0) {
      detections = await faceapi
        .detectAllFaces(imgElement, new faceapi.TinyFaceDetectorOptions({ inputSize: 416, scoreThreshold: 0.2 }))
        .withFaceLandmarks()
        .withFaceDescriptors();
    }

    const faceCount = detections.length;
    if (faceCount === 0) {
      return { faceCount: 0, hasFace: false, faces: [], descriptor: null };
    }

    const faces = detections.map((det, idx) => ({
      index: idx,
      descriptor: Array.from(det.descriptor)
    }));

    return {
      faceCount,
      hasFace: true,
      faces,
      descriptor: faces[0].descriptor
    };
  } catch (err) {
    console.error('Face detection error:', err);
    return { faceCount: 0, hasFace: false, faces: [], descriptor: null, error: err.message };
  }
};

const mapBoxToOverlay = (box, video, wrap) => {
  if (!box || !video || !wrap) return null;
  const videoW = video.videoWidth || 640;
  const videoH = video.videoHeight || 480;
  const displayW = wrap.clientWidth || 1;
  const displayH = wrap.clientHeight || 1;
  const scale = Math.max(displayW / videoW, displayH / videoH);
  const offsetX = (videoW * scale - displayW) / 2;
  const offsetY = (videoH * scale - displayH) / 2;
  return {
    left: box.x * scale - offsetX,
    top: box.y * scale - offsetY,
    width: box.width * scale,
    height: box.height * scale
  };
};

export const Attendance = () => {
  const { personnel = [], markAttendance, setActiveModal, showToast } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [deptFilter, setDeptFilter] = useState('All');

  const [isModelsReady, setIsModelsReady] = useState(modelsLoaded);
  const [modelLoadError, setModelLoadError] = useState(null);

  const videoRef = useRef(null);
  const overlayWrapRef = useRef(null);
  const mediaStreamRef = useRef(null);
  const [isWebcamActive, setIsWebcamActive] = useState(false);
  const [webcamStatus, setWebcamStatus] = useState('Camera initializing...');
  const [detectedFaces, setDetectedFaces] = useState([]);
  const [attendanceSuccessModal, setAttendanceSuccessModal] = useState(null);
  const [showInfoModal, setShowInfoModal] = useState(false);

  const referenceEmbeddingsRef = useRef({});
  const lastMarkedTimesRef = useRef({});
  const isProcessingRef = useRef(false);
  const personnelRef = useRef(personnel);
  const markAttendanceRef = useRef(markAttendance);
  const popupOpenRef = useRef(false);
  const popupQueueRef = useRef([]);

  useEffect(() => {
    personnelRef.current = personnel;
  }, [personnel]);

  useEffect(() => {
    markAttendanceRef.current = markAttendance;
  }, [markAttendance]);

  useEffect(() => {
    let isMounted = true;
    loadFaceModels()
      .then((ready) => {
        if (!isMounted) return;
        if (ready) {
          setIsModelsReady(true);
          setModelLoadError(null);
        } else {
          setIsModelsReady(false);
          setModelLoadError('AI Face Models Failed to Load');
        }
      })
      .catch(() => {
        if (!isMounted) return;
        setIsModelsReady(false);
        setModelLoadError('AI Face Models Failed to Load');
      });
    return () => {
      isMounted = false;
    };
  }, []);

  useEffect(() => {
    if (!isModelsReady || !personnel) return;
    personnel.forEach(async (member) => {
      if (!referenceEmbeddingsRef.current[member.id] && member.photoUrl) {
        try {
          const res = await detectAndExtractFaceDescriptor(member.photoUrl);
          if (res.hasFace && res.descriptor) {
            referenceEmbeddingsRef.current[member.id] = res.descriptor;
          }
        } catch {
          // ignore background preload error
        }
      }
    });
  }, [isModelsReady, personnel]);

  const startWebcam = async () => {
    try {
      setWebcamStatus('Starting camera...');
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: { ideal: 1280, min: 640 }, height: { ideal: 720, min: 480 }, facingMode: 'user' }
      });
      mediaStreamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      setIsWebcamActive(true);
      setWebcamStatus('Auto-detect on');
    } catch (err) {
      console.warn('Webcam permission denied or unavailable:', err);
      setWebcamStatus('Camera permission needed');
      setIsWebcamActive(false);
    }
  };

  const stopWebcam = () => {
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setIsWebcamActive(false);
    setWebcamStatus('Camera off');
    setDetectedFaces([]);
  };

  useEffect(() => {
    startWebcam();
    return () => stopWebcam();
  }, []);

  const showAttendancePopup = (data) => {
    if (popupOpenRef.current) {
      popupQueueRef.current.push(data);
      return;
    }
    popupOpenRef.current = true;
    setAttendanceSuccessModal(data);
    setTimeout(() => {
      setAttendanceSuccessModal(null);
      popupOpenRef.current = false;
      const next = popupQueueRef.current.shift();
      if (next) showAttendancePopup(next);
    }, 2800);
  };

  useEffect(() => {
    let intervalId = null;

    if (isWebcamActive && isModelsReady) {
      intervalId = setInterval(async () => {
        if (isProcessingRef.current) return;
        const video = videoRef.current;
        if (!video || video.paused || video.ended || video.readyState < 2) return;

        isProcessingRef.current = true;
        try {
          let detections = await faceapi
            .detectAllFaces(video, new faceapi.SsdMobilenetv1Options({ minConfidence: 0.25, maxResults: 12 }))
            .withFaceLandmarks()
            .withFaceDescriptors();

          if (detections.length === 0) {
            detections = await faceapi
              .detectAllFaces(video, new faceapi.TinyFaceDetectorOptions({ inputSize: 416, scoreThreshold: 0.25 }))
              .withFaceLandmarks()
              .withFaceDescriptors();
          }

          if (detections.length === 0) {
            setDetectedFaces([]);
            setWebcamStatus('Looking for faces...');
            return;
          }

          const roster = personnelRef.current || [];
          const candidates = [];

          for (let i = 0; i < detections.length; i += 1) {
            const det = detections[i];
            const liveDescriptor = det.descriptor;

            for (const member of roster) {
              let refEmbedding = referenceEmbeddingsRef.current[member.id];
              if (!refEmbedding && member.photoUrl) {
                const res = await detectAndExtractFaceDescriptor(member.photoUrl);
                if (res.hasFace && res.descriptor) {
                  refEmbedding = res.descriptor;
                  referenceEmbeddingsRef.current[member.id] = res.descriptor;
                }
              }
              if (!refEmbedding) continue;
              const dist = faceapi.euclideanDistance(liveDescriptor, new Float32Array(refEmbedding));
              candidates.push({ faceIndex: i, member, dist, box: det.detection.box });
            }
          }

          candidates.sort((a, b) => a.dist - b.dist);
          const usedFaces = new Set();
          const usedMembers = new Set();
          const matchByFace = {};

          for (const c of candidates) {
            if (c.dist > FACE_DISTANCE_THRESHOLD) continue;
            if (usedFaces.has(c.faceIndex) || usedMembers.has(c.member.id)) continue;
            usedFaces.add(c.faceIndex);
            usedMembers.add(c.member.id);
            matchByFace[c.faceIndex] = c;
          }

          const wrap = overlayWrapRef.current;
          const evaluatedFaces = detections.map((det, idx) => {
            const match = matchByFace[idx];
            const mapped = mapBoxToOverlay(det.detection.box, video, wrap);
            return {
              mapped,
              isMatched: Boolean(match),
              member: match?.member || null
            };
          });

          setDetectedFaces(evaluatedFaces);
          const matchedCount = evaluatedFaces.filter((f) => f.isMatched).length;
          setWebcamStatus(
            `${detections.length} face${detections.length > 1 ? 's' : ''} · ${matchedCount} matched`
          );

          const now = Date.now();
          for (const match of Object.values(matchByFace)) {
            const member = match.member;
            
            // Check if this studentId/member already has an attendance entry within the last 12 hours
            const lastMarked = Math.max(
              lastMarkedTimesRef.current[member.id] || 0,
              member.lastMarkedAt || 0
            );

            if (lastMarked > 0 && (now - lastMarked < TWELVE_HOURS_MS)) {
              // SKIP: Already marked within the last 12 hours (don't mark again, don't show success popup)
              continue;
            }

            // Mark attendance normally with current timestamp
            lastMarkedTimesRef.current[member.id] = now;

            markAttendanceRef.current(member.id, 'Present', { silent: true });
            showAttendancePopup({
              officer: member,
              time: new Date().toLocaleTimeString('en-US', { hour12: true })
            });
          }
        } catch (err) {
          console.warn('Webcam detection warning:', err);
        } finally {
          isProcessingRef.current = false;
        }
      }, 450);
    }

    return () => {
      if (intervalId) clearInterval(intervalId);
    };
  }, [isWebcamActive, isModelsReady]);

  const renderFaceOverlayBoxes = () => {
    if (!detectedFaces || detectedFaces.length === 0) return null;

    return (
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-20">
        {detectedFaces.map((face, idx) => {
          if (!face.mapped) return null;
          const { left, top, width, height } = face.mapped;
          const isMatch = face.isMatched;
          return (
            <div
              key={idx}
              style={{ left, top, width, height }}
              className={`absolute rounded-md border-[3px] ${
                isMatch ? 'border-emerald-400' : 'border-yellow-400'
              }`}
            >
              <span
                className={`absolute -top-6 left-0 px-2 py-0.5 rounded text-[10px] font-bold whitespace-nowrap ${
                  isMatch ? 'bg-emerald-500 text-black' : 'bg-yellow-400 text-black'
                }`}
              >
                {isMatch ? face.member?.name || 'Matched' : 'Detected'}
              </span>
            </div>
          );
        })}
      </div>
    );
  };

  const filtered = personnel.filter((p) => {
    const matchesSearch =
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDept = deptFilter === 'All' || p.department === deptFilter;
    return matchesSearch && matchesDept;
  });

  const total = personnel.length;
  const present = personnel.filter((p) => p.status === 'Present').length;
  const absent = personnel.filter((p) => p.status === 'Absent' || p.status === 'Registered').length;
  const late = personnel.filter((p) => p.status === 'Late').length;
  const departments = [
    'All',
    'Computer Science',
    'Cyber Security',
    'Operations',
    'Field Intelligence',
    'Tactical Command',
    'Surveillance Ops',
    'Administration',
    'Logistics'
  ];

  const handleDownloadAttendanceReport = (format = 'pdf') => {
    const timeNow = new Date().toLocaleString();
    const presentCount = personnel.filter(p => p.status === 'Present').length;
    const absentCount = personnel.filter(p => p.status === 'Absent' || p.status === 'Registered').length;
    const lateCount = personnel.filter(p => p.status === 'Late').length;

    if (format === 'csv') {
      let csvContent = 'ID,NAME,ROLE,DEPARTMENT,ENTRY_TIME,STATUS,BADGE_ID\n';
      personnel.forEach(p => {
        csvContent += `"${p.id}","${p.name}","${p.role || 'Member'}","${p.department}","${p.entry || '--'}","${p.status}","${p.badgeId || '--'}"\n`;
      });

      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `ATTENDANCE_REPORT_${new Date().toISOString().slice(0, 10)}.csv`;
      link.click();
      URL.revokeObjectURL(link);
      return;
    }

    try {
      const doc = new jsPDF();

      doc.setFillColor(6, 78, 59);
      doc.rect(0, 0, 210, 38, 'F');

      doc.setTextColor(255, 255, 255);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(14);
      doc.text('PROJECT CHAKRAVYUH - SMART ATTENDANCE REPORT', 14, 16);
      doc.setFontSize(10);
      doc.setTextColor(167, 243, 208);
      doc.text('AUTOMATIC AI BIOMETRIC CHECK-IN AUDIT DOSSIER', 14, 25);
      doc.setTextColor(226, 232, 240);
      doc.setFontSize(8);
      doc.text(`Generated: ${timeNow} | Total Records: ${personnel.length}`, 14, 32);

      doc.setFillColor(240, 253, 244);
      doc.rect(14, 45, 182, 22, 'F');
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(10);
      doc.setTextColor(15, 23, 42);
      doc.text(`Total Enrolled: ${personnel.length}`, 20, 58);
      doc.setTextColor(5, 150, 105);
      doc.text(`Present: ${presentCount}`, 75, 58);
      doc.setTextColor(220, 38, 38);
      doc.text(`Absent: ${absentCount}`, 125, 58);
      doc.setTextColor(217, 119, 6);
      doc.text(`Late: ${lateCount}`, 165, 58);

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(10);
      doc.setTextColor(15, 23, 42);
      doc.text('PERSONNEL ATTENDANCE ROSTER LOG', 14, 78);
      doc.setLineWidth(0.5);
      doc.setDrawColor(16, 185, 129);
      doc.line(14, 81, 196, 81);

      doc.setFontSize(9);
      doc.setFont('helvetica', 'bold');
      doc.text('ID', 14, 88);
      doc.text('NAME', 45, 88);
      doc.text('ROLE / DEPT', 95, 88);
      doc.text('ENTRY TIME', 145, 88);
      doc.text('STATUS', 175, 88);
      doc.line(14, 91, 196, 91);

      doc.setFont('helvetica', 'normal');
      let y = 98;
      personnel.forEach((p) => {
        if (y > 270) {
          doc.addPage();
          y = 20;
        }
        doc.text(String(p.id), 14, y);
        doc.text(String(p.name).slice(0, 24), 45, y);
        doc.text(`${p.role || 'Member'} (${p.department})`.slice(0, 26), 95, y);
        doc.text(String(p.entry || '--'), 145, y);
        
        if (p.status === 'Present') doc.setTextColor(5, 150, 105);
        else if (p.status === 'Late') doc.setTextColor(217, 119, 6);
        else doc.setTextColor(100, 116, 139);
        
        doc.text(String(p.status), 175, y);
        doc.setTextColor(15, 23, 42);
        y += 8;
      });

      doc.setFontSize(8);
      doc.setTextColor(148, 163, 184);
      doc.text('Official Biometric Audit Log — Project Chakravyuh Command & Control Portal', 14, 285);

      doc.save(`ATTENDANCE_REPORT_${new Date().toISOString().slice(0, 10)}.pdf`);
    } catch (err) {
      console.error('PDF export error:', err);
    }
  };

  return (
    <div className="space-y-6 select-none pb-8 text-slate-100">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-gradient-to-r from-emerald-950/90 via-slate-900 to-slate-950 border border-emerald-500/30 p-6 rounded-2xl shadow-xl">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shadow-md">
            <UserCheck className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-extrabold text-white tracking-tight">Smart Attendance Portal</h1>
            <p className="text-xs text-slate-400 mt-0.5">
              Auto multi-face detect · yellow = seen · green = matched
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          <button
            onClick={() => setShowInfoModal(true)}
            className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center gap-2 transition-all shadow-md cursor-pointer"
          >
            <Info className="w-4 h-4 text-emerald-400" />
            <span>Overview & Impact</span>
          </button>

          <button
            onClick={() => handleDownloadAttendanceReport('pdf')}
            className="px-4 py-2.5 rounded-xl bg-emerald-900/60 hover:bg-emerald-800/80 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center gap-2 transition-all shadow-md cursor-pointer"
          >
            <Download className="w-4 h-4 text-emerald-400" />
            <span>Download PDF Report</span>
          </button>

          <button
            onClick={() => handleDownloadAttendanceReport('csv')}
            className="px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-semibold text-slate-200 flex items-center gap-1.5 transition-all shadow-sm cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4 text-slate-300" />
            <span>CSV</span>
          </button>

          <button
            onClick={isWebcamActive ? stopWebcam : startWebcam}
            className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-semibold text-slate-200 flex items-center gap-2 transition-all shadow-sm cursor-pointer"
          >
            <RefreshCw className={`w-4 h-4 ${isWebcamActive ? 'text-emerald-400' : ''}`} />
            <span>{isWebcamActive ? 'Restart Camera' : 'Start Webcam'}</span>
          </button>

          <button
            onClick={() => setActiveModal('addPerson')}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-extrabold text-xs flex items-center gap-2 transition-all shadow-lg shadow-emerald-600/20 cursor-pointer"
          >
            <UserPlus className="w-4 h-4" />
            <span>Add New Data</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <StatCard title="Enrolled Personnel" value={String(total)} subtext="Total Staff & Students" icon={Users} />
        <StatCard title="Present Today" value={String(present)} subtext="Checked In" icon={UserCheck} indicatorDot="green" />
        <StatCard title="Absent" value={String(absent)} subtext="Not Present" icon={UserX} />
        <StatCard title="Late Check-ins" value={String(late)} subtext="After 09:15 AM" icon={Clock} />
      </div>

      {modelLoadError && (
        <p className="text-xs text-amber-400">{modelLoadError}. Face matching needs model files in /public/models.</p>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <div className="lg:col-span-5 bg-slate-900/90 border border-emerald-500/30 rounded-2xl p-5 space-y-4 shadow-xl">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <Camera className="w-4 h-4 text-emerald-400" />
              <span>Live Camera</span>
            </h2>
            <span className="text-[10px] font-bold px-2.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
              {webcamStatus}
            </span>
          </div>

          <div
            ref={overlayWrapRef}
            className="relative rounded-2xl overflow-hidden border border-slate-800 bg-black aspect-video flex items-center justify-center shadow-inner"
          >
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className="w-full h-full object-cover"
            />
            {isWebcamActive && renderFaceOverlayBoxes()}
            {!isWebcamActive && (
              <div className="absolute inset-0 flex flex-col items-center justify-center p-4 text-center bg-slate-950/90 z-10">
                <Camera className="w-10 h-10 text-emerald-400 mb-2 opacity-60" />
                <p className="text-xs font-semibold text-slate-300">Camera off</p>
                <button
                  onClick={startWebcam}
                  className="mt-3 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition-all cursor-pointer"
                >
                  Turn On Webcam
                </button>
              </div>
            )}
          </div>

          <p className="text-[11px] text-slate-400 text-center">
            Face in view = yellow box. Photo match = green box + attendance popup.
          </p>
        </div>

        <div className="lg:col-span-7 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-xl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-sm font-bold text-white">Personnel Attendance Roster</h2>
              <p className="text-xs text-slate-400 mt-0.5">Upload a photo, then stand in front of the camera</p>
            </div>

            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-500" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search staff name / ID..."
                  className="pl-8 pr-3 py-1.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <select
                value={deptFilter}
                onChange={(e) => setDeptFilter(e.target.value)}
                className="px-2.5 py-1.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500"
              >
                {departments.map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="overflow-x-auto rounded-xl border border-slate-800">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-950 border-b border-slate-800 text-slate-400 font-bold uppercase text-[10px] tracking-wider">
                  <th className="py-3 px-3.5">ID</th>
                  <th className="py-3 px-3.5">Member Photo & Name</th>
                  <th className="py-3 px-3.5">Department</th>
                  <th className="py-3 px-3.5">Entry Time</th>
                  <th className="py-3 px-3.5">Status</th>
                  <th className="py-3 px-3.5 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filtered.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-12 text-center text-slate-400">
                      <UserX className="w-10 h-10 mx-auto mb-2 text-slate-600 opacity-60" />
                      <p className="font-bold text-slate-200 text-xs">No Records Registered</p>
                      <p className="text-[11px] text-slate-500 mt-1">
                        Click Add New Data and upload a face photo so auto attendance can match.
                      </p>
                    </td>
                  </tr>
                ) : (
                  filtered.map((person) => (
                    <tr key={person.id} className="hover:bg-slate-800/40 transition-colors">
                      <td className="py-3 px-3.5 font-mono font-bold text-emerald-400">{person.id}</td>
                      <td className="py-3 px-3.5">
                        <div className="flex items-center space-x-3">
                          <div className="w-9 h-9 rounded-xl bg-slate-800 border border-emerald-500/30 overflow-hidden flex items-center justify-center text-lg flex-shrink-0">
                            {person.photoUrl ? (
                              <img src={person.photoUrl} alt={person.name} className="w-full h-full object-cover" />
                            ) : (
                              <span>{person.avatar || '👤'}</span>
                            )}
                          </div>
                          <div>
                            <span className="font-bold text-white block leading-tight">{person.name}</span>
                            <span className="text-[10px] text-slate-400 font-medium block mt-0.5">{person.role || 'Member'}</span>
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-3.5 text-slate-300 font-medium">{person.department}</td>
                      <td className="py-3 px-3.5 font-mono text-slate-300">{person.entry || '--'}</td>
                      <td className="py-3 px-3.5">
                        <span
                          className={`px-2.5 py-0.5 rounded-full font-bold text-[10px] ${
                            person.status === 'Present'
                              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                              : person.status === 'Late'
                              ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                              : 'bg-slate-800 text-slate-400 border border-slate-700'
                          }`}
                        >
                          {person.status}
                        </span>
                      </td>
                      <td className="py-3 px-3.5 text-right">
                        <button
                          onClick={() => markAttendance(person.id, person.status === 'Present' ? 'Absent' : 'Present')}
                          className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-[11px] font-semibold text-slate-200 transition-colors border border-slate-700 cursor-pointer"
                        >
                          {person.status === 'Present' ? 'Mark Absent' : 'Mark Present'}
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {attendanceSuccessModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-slate-900 border-2 border-emerald-500/60 rounded-2xl w-full max-w-sm p-6 text-center text-white relative shadow-2xl space-y-4">
            <button
              onClick={() => {
                setAttendanceSuccessModal(null);
                popupOpenRef.current = false;
              }}
              className="absolute top-3 right-3 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
            
            <div className="w-14 h-14 mx-auto rounded-full bg-emerald-500/20 border-2 border-emerald-400 flex items-center justify-center text-emerald-400 shadow-[0_0_20px_rgba(52,211,153,0.5)]">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div>
              <h3 className="text-lg font-extrabold text-white uppercase tracking-tight">Attendance Marked</h3>
              <p className="text-sm text-emerald-400 font-bold mt-1">{attendanceSuccessModal.officer.name}</p>
              <p className="text-xs text-slate-400 font-mono mt-0.5">
                ID: <span className="text-white font-bold">{attendanceSuccessModal.officer.id}</span> · {attendanceSuccessModal.time}
              </p>
            </div>

            {attendanceSuccessModal.officer.photoUrl && (
              <img
                src={attendanceSuccessModal.officer.photoUrl}
                alt=""
                className="w-20 h-20 rounded-2xl object-cover mx-auto border-2 border-emerald-500/40 shadow-md"
              />
            )}

            <div className="pt-2 flex items-center justify-center gap-2">
              <button
                onClick={() => handleDownloadAttendanceReport('pdf')}
                className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-extrabold text-xs flex items-center justify-center gap-2 transition-all shadow-md shadow-emerald-600/30 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Download Attendance PDF Report</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 🎓 SMART ATTENDANCE SYSTEM — COMPLETE OVERVIEW, IMPACT & BENEFITS BRIEFING MODAL */}
      {showInfoModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-emerald-500/40 rounded-3xl w-full max-w-4xl max-h-[90vh] overflow-y-auto shadow-2xl p-6 sm:p-8 space-y-6 text-white relative">
            
            {/* Modal Header */}
            <div className="flex justify-between items-start border-b border-slate-800 pb-5">
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <span className="text-2xl">🎓</span>
                  <span className="px-3 py-1 rounded-md bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 font-bold text-sm">
                    SMART CAMPUS & ENTERPRISE BIOMETRIC BRIEFING
                  </span>
                </div>
                <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
                  Smart Attendance System — Overview, Impact & Key Benefits
                </h2>
                <p className="text-base text-slate-300">
                  Comprehensive breakdown of automated AI multi-face biometric check-in, real-time roster analytics, and key operational advantages.
                </p>
              </div>
              <button
                onClick={() => setShowInfoModal(false)}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors cursor-pointer"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Section 1: System Overview */}
            <div className="space-y-3 bg-slate-950/80 border border-slate-800 p-5 rounded-2xl">
              <h3 className="font-extrabold text-lg text-emerald-400 flex items-center gap-2">
                <span>🎯 1. System Overview</span>
              </h3>
              <p className="text-sm text-slate-300 leading-relaxed font-normal">
                The <strong className="text-white font-bold">Smart Attendance System</strong> is an automated, AI-powered contactless biometric verification platform designed for educational institutions (schools, colleges, universities) and corporate enterprises. Utilizing live CCTV feeds and webcams, the system performs real-time multi-face detection, extracts 128-dimensional facial feature vectors, and instantly marks attendance against enrolled rosters within milliseconds.
              </p>
            </div>

            {/* Section 2: Real-World Impact & Time Savings */}
            <div className="space-y-3 bg-slate-950/80 border border-slate-800 p-5 rounded-2xl">
              <h3 className="font-extrabold text-lg text-teal-400 flex items-center gap-2">
                <span>🚀 2. Real-World Impact & Operational Efficiency</span>
              </h3>
              <ul className="text-sm text-slate-300 space-y-2.5 list-disc pl-6 leading-relaxed font-normal">
                <li><strong className="text-white font-bold">Eliminates Manual Roll-Calls:</strong> Saves 10 to 15 minutes per lecture or shift, returning hundreds of valuable instructional hours annually to teachers and students.</li>
                <li><strong className="text-white font-bold">Zero Proxy Attendance & Time Fraud:</strong> AI facial recognition eliminates buddy-punching, fraudulent sign-ins, and manual attendance manipulation.</li>
                <li><strong className="text-white font-bold">Touchless & Hygienic Access:</strong> Contactless check-in prevents bottleneck queues at physical turnstiles and fingerprint scanners.</li>
                <li><strong className="text-white font-bold">Automated Roster Analytics:</strong> Live check-in streams provide management with instant attendance visibility, absentee logs, and shift performance summaries.</li>
              </ul>
            </div>

            {/* Section 3: Key Strategic Benefits (System Advantages) */}
            <div className="space-y-3 bg-slate-950/80 border border-slate-800 p-5 rounded-2xl">
              <h3 className="font-extrabold text-lg text-emerald-400 flex items-center gap-2">
                <span>🛡️ 3. Key Benefits & System Advantages</span>
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
                <div className="p-4 rounded-xl bg-slate-900 border border-emerald-500/30 space-y-1.5 shadow-xs">
                  <span className="font-bold text-emerald-400 text-sm block">⚡ 12ms Instant Multi-Face Detection</span>
                  <p className="text-xs text-slate-300 leading-relaxed">Detects and verifies multiple individuals simultaneously as they walk past entry gates without stopping or queuing.</p>
                </div>

                <div className="p-4 rounded-xl bg-slate-900 border border-emerald-500/30 space-y-1.5 shadow-xs">
                  <span className="font-bold text-emerald-400 text-sm block">⏳ 12-Hour Anti-Duplicate Cooldown</span>
                  <p className="text-xs text-slate-300 leading-relaxed">Smart anti-duplicate logic suppresses repeated check-ins and duplicate popups when a student repeatedly passes the camera.</p>
                </div>

                <div className="p-4 rounded-xl bg-slate-900 border border-emerald-500/30 space-y-1.5 shadow-xs">
                  <span className="font-bold text-emerald-400 text-sm block">🔊 Instant Speech Feedback & Overlay</span>
                  <p className="text-xs text-slate-300 leading-relaxed">Provides audio announcements ("Attendance marked for [Name]") and live green bounding box overlays for visual confirmation.</p>
                </div>

                <div className="p-4 rounded-xl bg-slate-900 border border-emerald-500/30 space-y-1.5 shadow-xs">
                  <span className="font-bold text-emerald-400 text-sm block">📄 One-Click PDF & CSV Export</span>
                  <p className="text-xs text-slate-300 leading-relaxed">Instantly export daily attendance rosters, shift audit logs, and individual student check-in receipt PDFs with a single click.</p>
                </div>
              </div>
            </div>

            {/* Modal Actions Footer */}
            <div className="flex justify-end pt-3 border-t border-slate-800">
              <button
                onClick={() => setShowInfoModal(false)}
                className="px-6 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-sm transition-colors cursor-pointer"
              >
                Close Briefing
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Attendance;
