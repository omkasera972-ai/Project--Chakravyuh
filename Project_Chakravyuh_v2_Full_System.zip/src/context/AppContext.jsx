import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  initialKPIs,
  initialCameras,
  initialAlerts,
  initialPersonnel,
  initialWatchlist,
  initialVehicles,
  initialMissingChildren,
  initialDepotInventory,
  initialMovementLogs,
  crimeOverviewData,
  incidentsOverTimeData,
} from '../data/mockData';

const AppContext = createContext();

export const AppProvider = ({ children }) => {
  // Authentication & Module State
  const [isAuthenticated, setIsAuthenticated] = useState(() => {
    return localStorage.getItem('sda_auth') === 'true';
  });

  const [activeModule, setActiveModule] = useState(() => {
    return localStorage.getItem('sda_active_module') || 'attendance';
  });

  const [user, setUser] = useState(() => {
    const saved = localStorage.getItem('sda_user');
    return saved ? JSON.parse(saved) : {
      name: 'Command Admin',
      role: 'Super Officer',
      badge: 'BADGE-SYS-2026',
      unit: 'Central Command & Control'
    };
  });

  // Core Datasets
  const [kpis, setKpis] = useState(() => {
    const saved = localStorage.getItem('sda_kpis');
    return saved ? JSON.parse(saved) : initialKPIs;
  });

  const [cameras, setCameras] = useState(() => {
    const saved = localStorage.getItem('sda_cameras');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return initialCameras.map(ic => {
            const savedItem = parsed.find(c => c.id === ic.id);
            return savedItem ? { ...ic, status: savedItem.status || ic.status } : ic;
          });
        }
      } catch (e) {
        console.error(e);
      }
    }
    return initialCameras;
  });

  const [alerts, setAlerts] = useState(() => {
    const saved = localStorage.getItem('sda_alerts');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          return parsed
            .filter(a => !a.title?.includes('ATTENDANCE MARKED') && !a.type?.includes('Attendance Check-in'))
            .map(a => {
              let mod = a.module;
              let desc = a.description || '';
              let title = a.title || '';

              // If description or title contains Case MC- or Missing Child, route to missing-child module
              if (desc.includes('Case MC-') || title.includes('MISSING CHILD') || a.type?.includes('Missing')) {
                mod = 'missing-child';
              } else if (!mod) {
                if (a.type?.includes('ANPR') || a.icon === 'Car') mod = 'anpr';
                else if (a.type?.includes('Breach') || a.type?.includes('Armory') || a.icon === 'Shield') mod = 'defence';
                else mod = 'criminal-tracking';
              }

              // If alert is criminal-tracking, sanitize any accidental Case MC- string to Wanted Suspect
              if (mod === 'criminal-tracking' && desc.includes('Case MC-')) {
                desc = desc.replace(/for Case MC-[\w-]+/gi, 'for Wanted Suspect (W-4028)');
              }

              return { ...a, module: mod, description: desc };
            });
        }
      } catch (e) {
        console.error('Error parsing sda_alerts:', e);
      }
    }
    return initialAlerts.filter(a => !a.title?.includes('ATTENDANCE MARKED') && !a.type?.includes('Attendance Check-in'));
  });

  const [personnel, setPersonnel] = useState(() => {
    const saved = localStorage.getItem('sda_personnel');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          // Purge old initial fake placeholder entries (EMP-001..EMP-008)
          return parsed.filter(p => !p.id.startsWith('EMP-00') && p.name !== 'Rahul Sharma' && p.name !== 'Priya Patel');
        }
      } catch (e) {
        console.error('Error parsing sda_personnel:', e);
      }
    }
    return initialPersonnel;
  });

  const [watchlist, setWatchlist] = useState(() => {
    const saved = localStorage.getItem('sda_watchlist');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          // Schema migration: Strip out old non-128D embeddings
          return parsed.map(item => {
            if (item.embedding && (!Array.isArray(item.embedding) || item.embedding.length !== 128)) {
              console.warn(`Migrating watchlist schema: cleared non-128D embedding for ${item.name} (${item.id})`);
              return { ...item, embedding: null };
            }
            return item;
          });
        }
      } catch (err) {
        console.error("Error parsing watchlist from localStorage:", err);
      }
    }
    return initialWatchlist;
  });

  const [vehicles, setVehicles] = useState(() => {
    const saved = localStorage.getItem('sda_vehicles');
    return saved ? JSON.parse(saved) : initialVehicles;
  });

  const [missingChildren, setMissingChildren] = useState(() => {
    const saved = localStorage.getItem('sda_missing_children');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      } catch (e) {
        console.error('Error parsing sda_missing_children:', e);
      }
    }
    return initialMissingChildren;
  });

  const [depotInventory, setDepotInventory] = useState(() => {
    const saved = localStorage.getItem('sda_inventory');
    return saved ? JSON.parse(saved) : initialDepotInventory;
  });

  const [movementLogs, setMovementLogs] = useState(() => {
    const saved = localStorage.getItem('sda_movement_logs');
    return saved ? JSON.parse(saved) : initialMovementLogs;
  });

  // Detection Reports for Missing Children
  const [detectionReports, setDetectionReports] = useState(() => {
    const saved = localStorage.getItem('sda_detection_reports');
    return saved ? JSON.parse(saved) : [];
  });

  // Global UI States, Modals & Theme
  const [theme, setTheme] = useState(() => {
    return localStorage.getItem('sda_theme') || 'light';
  });

  const toggleTheme = () => {
    setTheme(prev => (prev === 'light' ? 'dark' : 'light'));
  };

  useEffect(() => {
    localStorage.setItem('sda_theme', theme);
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  const [globalSearch, setGlobalSearch] = useState('');
  const [selectedCameraForModal, setSelectedCameraForModal] = useState(null);
  const [activeModal, setActiveModal] = useState(null); // 'addAlert', 'searchPerson', 'searchVehicle', 'generateReport', 'addPerson', 'addWatchlist', 'addMissingChild'
  const [toastMessage, setToastMessage] = useState(null);

  // Sync to LocalStorage
  useEffect(() => {
    localStorage.setItem('sda_auth', isAuthenticated);
  }, [isAuthenticated]);

  useEffect(() => {
    try {
      localStorage.setItem('sda_kpis', JSON.stringify(kpis));
      localStorage.setItem('sda_cameras', JSON.stringify(cameras));
      localStorage.setItem('sda_alerts', JSON.stringify(alerts));
      localStorage.setItem('sda_personnel', JSON.stringify(personnel));
      localStorage.setItem('sda_watchlist', JSON.stringify(watchlist));
      localStorage.setItem('sda_vehicles', JSON.stringify(vehicles));

      // Sanitize missingChildren photos to prevent Storage Quota errors
      const sanitizedChildren = missingChildren.map(child => {
        if (child.photoUrl && child.photoUrl.startsWith('data:image') && child.photoUrl.length > 150000) {
          return { ...child, photoUrl: 'https://images.unsplash.com/photo-1543332164-6e82f355badc?w=400&auto=format&fit=crop&q=80' };
        }
        return child;
      });

      localStorage.setItem('sda_missing_children', JSON.stringify(sanitizedChildren));
      localStorage.setItem('sda_inventory', JSON.stringify(depotInventory));
      localStorage.setItem('sda_movement_logs', JSON.stringify(movementLogs));
      localStorage.setItem('sda_detection_reports', JSON.stringify(detectionReports));
    } catch (err) {
      console.warn('localStorage save quota limit reached (prevented crash):', err);
    }
  }, [kpis, cameras, alerts, personnel, watchlist, vehicles, missingChildren, depotInventory, movementLogs]);

  // Toast Notification helper
  const showToast = (title, message, type = 'info') => {
    setToastMessage({ title, message, type, id: Date.now() });
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Auth Handlers
  const loginModule = (moduleId, userData) => {
    setIsAuthenticated(true);
    setActiveModule(moduleId);
    const updatedUser = {
      name: userData?.name || 'Officer Admin',
      role: userData?.role || 'Command Officer',
      badge: userData?.badge || `BADGE-${moduleId.toUpperCase()}-2026`,
      unit: `${moduleId.toUpperCase()} Command Division`
    };
    setUser(updatedUser);
    localStorage.setItem('sda_auth', 'true');
    localStorage.setItem('sda_active_module', moduleId);
    localStorage.setItem('sda_user', JSON.stringify(updatedUser));
  };

  const login = (role = 'Super Admin') => {
    setIsAuthenticated(true);
    setUser(prev => ({ ...prev, role }));
    showToast('Authenticated', 'Access granted to Command & Control Hub', 'success');
  };

  const logout = () => {
    setIsAuthenticated(false);
    localStorage.removeItem('sda_auth');
    showToast('Logged Out', 'Session terminated successfully', 'info');
  };

  // Personnel Handlers
  const addPerson = (newPerson) => {
    const person = {
      id: newPerson.id || `EMP-${Math.floor(1000 + Math.random() * 9000)}`,
      module: newPerson.module || activeModule || 'attendance',
      name: newPerson.name,
      department: newPerson.department || 'Security',
      role: newPerson.role || 'Officer',
      entry: newPerson.entry || '--',
      exit: '--',
      status: newPerson.status || 'Registered',
      camera: newPerson.camera || 'CAM-01',
      avatar: newPerson.avatar || '👤',
      photoUrl: newPerson.photoUrl || null,
      badgeId: `BADGE-${Math.floor(1000 + Math.random() * 9000)}`
    };
    setPersonnel(prev => [person, ...prev]);
    showToast('Personnel Registered', `${person.name} (${person.id}) registered successfully.`, 'success');
  };

  const markAttendance = (empId, status = 'Present', options = {}) => {
    const timeNow = new Date().toTimeString().slice(0, 5);
    const now = Date.now();
    let markedName = empId;
    setPersonnel(prev => prev.map(p => {
      if (p.id === empId || p.name === empId) {
        markedName = p.name;
        return {
          ...p,
          status,
          entry: p.entry === '--' ? timeNow : p.entry,
          lastMarkedAt: status === 'Present' ? now : p.lastMarkedAt,
          camera: 'CAM-01'
        };
      }
      return p;
    }));
    if (!options.silent) {
      showToast('Attendance Logged', `Attendance verified for ${markedName}. Status: ${status}`, 'success');
    }
  };

  // Watchlist Handlers
  const addToWatchlist = (item) => {
    const record = {
      id: item.id || `W-${Math.floor(9000 + Math.random() * 999)}`,
      module: item.module || activeModule || 'criminal-tracking',
      name: item.name,
      riskLevel: item.riskLevel || 'High Risk',
      crimeType: item.crimeType || 'Under Surveillance',
      lastSeen: item.lastSeen || 'CAM-03 Highway',
      status: 'Active Alert',
      confidence: item.confidence || '95%',
      photoUrl: item.photoUrl || null,
      photo: item.photo || '👤',
      age: item.age || 32,
      aliases: item.aliases || [item.name.split(' ')[0] || 'Suspect'],
      recordDate: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      details: item.details || item.crimeType || 'Added manually to criminal watchlist',
      isUserAdded: item.isUserAdded || false,
      embedding: item.embedding && Array.isArray(item.embedding) && item.embedding.length === 128 ? item.embedding : null,
      embeddingMetadata: item.embeddingMetadata || null
    };
    setWatchlist(prev => [record, ...prev]);
    showToast('Watchlist Updated', `Target ${record.name} added to surveillance watchlist.`, 'warning');
  };

  const removeFromWatchlist = (id) => {
    if (!id) return;
    setWatchlist(prev => prev.filter(w => w.id !== id));
    showToast('Profile Removed', `Watchlist record ${id} removed successfully.`, 'info');
  };

  const clearCustomWatchlist = () => {
    setWatchlist(prev => prev.filter(w => !w.isUserAdded));
    showToast('Custom Profiles Cleared', 'All custom user-registered profiles removed.', 'info');
  };

  const resetWatchlist = () => {
    localStorage.removeItem('sda_watchlist');
    setWatchlist(initialWatchlist);
    showToast('Watchlist Reset', 'Watchlist database reset to initial state.', 'info');
  };

  // Alert Handlers
  const addAlert = (alertData) => {
    if (alertData.type?.includes('Attendance Check-in') || alertData.title?.includes('ATTENDANCE MARKED')) {
      return; // Never push attendance check-ins into threat alerts array
    }
    const newAlert = {
      id: `ALT-${Math.floor(200 + Math.random() * 800)}`,
      module: alertData.module || activeModule || 'criminal-tracking',
      type: alertData.type || 'Custom Incident Alert',
      title: alertData.title || alertData.type,
      location: alertData.location || 'Central Sector',
      camera: alertData.camera || 'CAM-01',
      priority: alertData.priority || 'High',
      timeAgo: 'Just now',
      description: alertData.description || 'Reported manual alert via Command Console.',
      status: 'Active',
      icon: alertData.priority === 'Critical' ? 'Shield' : 'AlertTriangle',
      badgeColor: alertData.priority === 'Critical' ? 'border-red-500/50 text-red-400' : 'border-amber-500/40 text-amber-400'
    };
    setAlerts(prev => [newAlert, ...prev]);
    // update KPI
    setKpis(prev => ({
      ...prev,
      activeAlerts: { ...prev.activeAlerts, value: String(parseInt(prev.activeAlerts.value) + 1) }
    }));
    showToast('Alert Dispatched', `${newAlert.title} broadcasted to active units.`, 'warning');
  };

  const acknowledgeAlert = (id) => {
    setAlerts(prev => prev.map(a => a.id === id ? { ...a, status: 'Acknowledged' } : a));
    showToast('Alert Acknowledged', `Incident ${id} acknowledged by Command.`, 'info');
  };

  const resolveAlert = (id) => {
    setAlerts(prev => prev.map(a => a.id === id ? { ...a, status: 'Resolved' } : a));
    setKpis(prev => ({
      ...prev,
      activeAlerts: { ...prev.activeAlerts, value: String(Math.max(0, parseInt(prev.activeAlerts.value) - 1)) }
    }));
    showToast('Alert Resolved', `Incident ${id} marked as resolved.`, 'success');
  };

  const deleteAlert = (id) => {
    setAlerts(prev => prev.filter(a => a.id !== id));
    showToast('Alert Deleted', `Alert ${id} permanently removed.`, 'info');
  };

  const deleteMultipleAlerts = (idsArray) => {
    if (!idsArray || idsArray.length === 0) return;
    setAlerts(prev => prev.filter(a => !idsArray.includes(a.id)));
    showToast('Alerts Deleted', `${idsArray.length} alert(s) permanently removed.`, 'info');
  };

  const clearAllAlerts = () => {
    setAlerts([]);
    showToast('All Alerts Cleared', 'All alerts permanently removed.', 'info');
  };

  // Missing Child Handlers
  const addMissingChild = (childData) => {
    const newCase = {
      id: childData.id || `MC-2026-${String(Math.floor(100 + Math.random() * 900))}`,
      module: childData.module || activeModule || 'missing-child',
      name: childData.name,
      age: parseInt(childData.age) || 6,
      gender: childData.gender || 'Unknown',
      lastSeenLocation: childData.lastSeenLocation || 'Central District',
      description: childData.description || 'No description provided.',
      photoUrl: childData.photoUrl || 'https://images.unsplash.com/photo-1543332164-6e82f355badc?w=400&auto=format&fit=crop&q=80',
      reportedTime: 'Just now',
      status: 'Searching',
      lastCameraScan: 'Scanning cameras...',
      matchedLocation: 'Pending network match',
      lat: 22.7250,
      lng: 75.8600
    };
    setMissingChildren(prev => [newCase, ...prev]);
    setKpis(prev => ({
      ...prev,
      missingChildren: { ...prev.missingChildren, value: String(parseInt(prev.missingChildren.value) + 1) }
    }));
    showToast('Case Registered', `Missing child case ${newCase.id} initiated. Camera sweep activated.`, 'warning');
  };

  const deleteMissingChild = (id) => {
    setMissingChildren(prev => prev.filter(c => c.id !== id));
    showToast('Case Removed', `Missing child case ${id} removed from registry.`, 'info');
  };

  // Add Detection Report (when face matches missing child)
  const addDetectionReport = (childData, confidence, location) => {
    const newReport = {
      id: `RPT-${Math.floor(10000 + Math.random() * 90000)}`,
      childId: childData.id,
      childName: childData.name,
      age: childData.age,
      gender: childData.gender,
      matchConfidence: String(confidence),
      detectedLocation: location || childData.lastSeenLocation,
      timestamp: new Date().toLocaleString(),
      photoUrl: childData.photoUrl,
      description: childData.description,
      status: 'LOCATED & VERIFIED',
      rescueStatus: 'Patrol Dispatched'
    };
    setDetectionReports(prev => [newReport, ...prev]);
    showToast('Detection Report Generated', `Match confirmed: ${childData.name} located at ${location}`, 'success');
  };

  // ANPR Handlers
  const addVehicleRecord = (veh) => {
    const record = {
      ...veh,
      module: veh.module || activeModule || 'anpr'
    };
    setVehicles(prev => [record, ...prev]);
    showToast('ANPR Logged', `Vehicle ${veh.plate} indexed in ANPR registry.`, 'info');
  };

  // Defence Inventory Handlers
  const updateDepotMovement = (itemId, type, quantityChange) => {
    const timeNow = new Date().toTimeString().slice(0, 5);
    setDepotInventory(prev => prev.map(item => {
      if (item.id === itemId || item.item.includes(itemId)) {
        const newQty = Math.max(0, item.quantity + quantityChange);
        return { ...item, quantity: newQty, lastChecked: 'Just now (Verified Movement)' };
      }
      return item;
    }));

    const log = {
      id: `MOV-${Math.floor(2000 + Math.random() * 8000)}`,
      time: timeNow,
      item: itemId,
      type: type || 'Authorized Transfer',
      officer: `${user.name} (${user.badge})`,
      status: 'Logged & Verified',
      zone: 'Depot A - Main Gate'
    };
    setMovementLogs(prev => [log, ...prev]);
    showToast('Movement Logged', `Authorized transfer of ${itemId} recorded.`, 'success');
  };

  const triggerMovementBreach = (zone, details) => {
    const alertItem = {
      type: 'Perimeter Breach',
      title: 'UNAUTHORIZED MOVEMENT DETECTED',
      location: zone || 'Defense Zone 3',
      camera: 'CAM-06',
      priority: 'Critical',
      description: details || 'Sensors tripped at Armory Vault. Thermal perimeter breach confirmed.'
    };
    addAlert(alertItem);
  };

  // Camera Management
  const toggleCameraStatus = (id) => {
    setCameras(prev => prev.map(c => {
      if (c.id === id) {
        const nextStatus = c.status === 'Online' ? 'Offline' : 'Online';
        showToast('Camera Status Changed', `${c.id} (${c.name}) is now ${nextStatus}`, 'info');
        return { ...c, status: nextStatus };
      }
      return c;
    }));
  };

  // Sidebar Collapsed State
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const toggleSidebar = () => setIsSidebarCollapsed(prev => !prev);

  // Dynamic Real-Time Calculated KPIs from actual state
  const calculatedKPIs = {
    totalPersonnel: { value: String(personnel.length), label: 'Total Person', subtext: 'Registered Officers' },
    activeCameras: { value: '1', label: 'Active Camera', subtext: 'Live Desktop Webcam' },
    activeAlerts: { value: String(alerts.filter(a => a.status === 'Active').length), label: 'Active Alerts', subtext: 'Live Triage' },
    criminalsTracked: { value: String(watchlist.length), label: 'Criminals Tracked', subtext: 'Watchlist Suspects' },
    missingChildren: { value: String(missingChildren.filter(m => m.status === 'Missing').length), label: 'Missing Children', subtext: 'Active Cases' },
  };

  return (
    <AppContext.Provider
      value={{
        isAuthenticated,
        activeModule,
        setActiveModule,
        loginModule,
        user,
        kpis: calculatedKPIs,
        calculatedKPIs,
        cameras,
        alerts,
        personnel,
        watchlist,
        vehicles,
        missingChildren,
        depotInventory,
        movementLogs,
        detectionReports,
        crimeOverviewData,
        incidentsOverTimeData,
        theme,
        setTheme,
        toggleTheme,
        isSidebarCollapsed,
        setIsSidebarCollapsed,
        toggleSidebar,
        globalSearch,
        setGlobalSearch,
        selectedCameraForModal,
        setSelectedCameraForModal,
        activeModal,
        setActiveModal,
        toastMessage,
        showToast,
        login,
        logout,
        addPerson,
        markAttendance,
        addToWatchlist,
        removeFromWatchlist,
        clearCustomWatchlist,
        resetWatchlist,
        addAlert,
        acknowledgeAlert,
        resolveAlert,
        deleteAlert,
        deleteMultipleAlerts,
        clearAllAlerts,
        addMissingChild,
        deleteMissingChild,
        addDetectionReport,
        addVehicleRecord,
        updateDepotMovement,
        triggerMovementBreach,
        toggleCameraStatus
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => useContext(AppContext);
