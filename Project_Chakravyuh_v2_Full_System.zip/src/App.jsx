import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useParams } from 'react-router-dom';
import { AppProvider, useApp } from './context/AppContext';
import { MainLayout } from './layouts/MainLayout';
import { PurposeSelector } from './pages/PurposeSelector';
import { ModuleLogin } from './pages/ModuleLogin';
import { Dashboard } from './pages/Dashboard';
import { Attendance } from './pages/Attendance';
import { CriminalTracking } from './pages/CriminalTracking';
import { AnprSystem } from './pages/AnprSystem';
import { MissingChild } from './pages/MissingChild';
import { DefenceTracker } from './pages/DefenceTracker';
import { CameraNetwork } from './pages/CameraNetwork';
import { Alerts } from './pages/Alerts';
import { Maps } from './pages/Maps';
import { Reports } from './pages/Reports';
import { Settings } from './pages/Settings';

// Route guard component enforcing strict 100% module security & access isolation
const ProtectedRoute = ({ children }) => {
  const { isAuthenticated, activeModule, setActiveModule } = useApp();
  const { moduleId } = useParams();

  // Retrieve authorized module for this session
  const authorizedModule = localStorage.getItem('sda_active_module') || activeModule;

  useEffect(() => {
    if (moduleId && authorizedModule && moduleId === authorizedModule) {
      setActiveModule(moduleId);
    }
  }, [moduleId, authorizedModule, setActiveModule]);

  if (!isAuthenticated) {
    return <Navigate to={moduleId ? `/portal/${moduleId}/login` : '/'} replace />;
  }

  // 🔒 SECURITY GATE ENFORCEMENT:
  // If an operator tries to access a different module than the one authorized for this session,
  // block cross-module access and redirect back to their authorized module workspace!
  if (moduleId && authorizedModule && moduleId !== authorizedModule) {
    console.warn(`[SECURITY GATE] Cross-module access denied: ${moduleId}. Redirecting to authorized workspace: ${authorizedModule}`);
    return <Navigate to={`/portal/${authorizedModule}/dashboard`} replace />;
  }

  return children;
};

// Component to select proper primary feature screen based on module ID
const ModuleDashboardWrapper = () => {
  return <Dashboard />;
};

const AppRoutes = () => {
  return (
    <Routes>
      {/* 1. Software Opening Purpose Selector Landing Page */}
      <Route path="/" element={<PurposeSelector />} />

      {/* 2. Dedicated Login/Signup Portal per Module */}
      <Route path="/portal/:moduleId/login" element={<ModuleLogin />} />

      {/* Legacy login fallback */}
      <Route path="/login" element={<Navigate to="/" replace />} />

      {/* 3. Protected Module Workspace & Navigation Workflows */}
      <Route
        path="/portal/:moduleId"
        element={
          <ProtectedRoute>
            <MainLayout />
          </ProtectedRoute>
        }
      >
        <Route path="dashboard" element={<ModuleDashboardWrapper />} />
        <Route path="attendance" element={<Attendance />} />
        <Route path="criminal-tracking" element={<CriminalTracking />} />
        <Route path="anpr" element={<AnprSystem />} />
        <Route path="missing-child" element={<MissingChild />} />
        <Route path="defence" element={<DefenceTracker />} />
        <Route path="cameras" element={<CameraNetwork />} />
        <Route path="alerts" element={<Alerts />} />
        <Route path="maps" element={<Maps />} />
        <Route path="reports" element={<Reports />} />
        <Route path="settings" element={<Settings />} />
      </Route>

      {/* Catch-all redirect to Purpose Selector */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
};

export const App = () => {
  return (
    <AppProvider>
      <Router future={{ v7_startTransition: true, v7_relativeSplatPath: true }}>
        <AppRoutes />
      </Router>
    </AppProvider>
  );
};

export default App;
